/* Turn pasted Excel/CSV text, or a photo, into the guide's grid. Results are proposals the merchant reviews. */
(() => {
'use strict';
const MAX_COLUMNS=10,MAX_ROWS=30;
const NUMERIC=/^[\d٠-٩۰-۹.,٫]+(?:\s*[-–]\s*[\d٠-٩۰-۹.,٫]+)?$/;
function delimiterOf(text){
  const line=text.split(/\r?\n/).find(l=>l.trim())||'';
  if(line.includes('\t'))return '\t';
  const counts=[';',',','|'].map(d=>[d,line.split(d).length-1]).sort((a,b)=>b[1]-a[1]);
  return counts[0][1]>0?counts[0][0]:',';
}
/* RFC 4180-style parsing: quoted fields may contain delimiters, quotes ("") and line breaks. */
function parseRows(text){
  const delimiter=delimiterOf(String(text||'')),rows=[];let row=[],field='',quoted=false;
  const input=String(text||'').replace(/^﻿/,'');
  for(let i=0;i<input.length;i++){
    const c=input[i];
    if(quoted){if(c==='"'){if(input[i+1]==='"'){field+='"';i++;}else quoted=false;}else field+=c;}
    else if(c==='"'&&field==='')quoted=true;
    else if(c===delimiter){row.push(field);field='';}
    else if(c==='\n'||c==='\r'){if(c==='\r'&&input[i+1]==='\n')i++;row.push(field);rows.push(row);row=[];field='';}
    else field+=c;
  }
  if(field!==''||row.length){row.push(field);rows.push(row);}
  return rows.map(r=>r.map(cell=>cell.replace(/\s+/g,' ').trim())).filter(r=>r.some(Boolean));
}
function unique(labels){
  const seen=new Set();
  return labels.map((raw,i)=>{const base=(raw||'').slice(0,40)||'عمود '+(i+1);let label=base,n=1;
    while(seen.has(label.toLowerCase())){n++;label=base.slice(0,36)+' '+n;}
    seen.add(label.toLowerCase());return label;});
}
/* First column = size names, first row = headers. Throws a readable message when nothing usable was pasted. */
function toGrid(text, {requireAll=false}={}){
  const rows=parseRows(text);
  if(rows.length<2||Math.max(...rows.map(r=>r.length))<2)throw new Error('الصق جدولًا يحتوي صفًا للعناوين وصفًا واحدًا على الأقل، وعمودين على الأقل.');
  const warnings=[],width=Math.max(...rows.map(r=>r.length)),header=rows[0];
  if(requireAll && (width-1>MAX_COLUMNS || rows.length-1>MAX_ROWS))throw new Error(`يدعم الجدول حتى ${MAX_ROWS} مقاسًا و${MAX_COLUMNS} أعمدة قياس. قسّم الجدول ثم أعد الاستيراد.`);
  if(width-1>MAX_COLUMNS)warnings.push(`تم أخذ أول ${MAX_COLUMNS} أعمدة قياس فقط.`);
  const labels=unique(Array.from({length:Math.min(width-1,MAX_COLUMNS)},(_,i)=>header[i+1]||''));
  let body=rows.slice(1);if(body.length>MAX_ROWS){warnings.push(`تم أخذ أول ${MAX_ROWS} صفًا فقط.`);body=body.slice(0,MAX_ROWS);}
  const grid=body.map(r=>({size:(r[0]||'').slice(0,30),values:labels.map((_,i)=>(r[i+1]||'').slice(0,60))}));
  const columns=labels.map((label,i)=>{const cells=grid.map(r=>r.values[i]).filter(Boolean);
    return {label,kind:cells.length&&cells.every(c=>NUMERIC.test(c))?'measurement':'text'};});
  if(grid.some(r=>!r.size))warnings.push('بعض الصفوف بلا اسم مقاس.');
  const blanks=grid.reduce((n,r)=>n+r.values.filter(v=>!v).length,0);
  if(blanks)warnings.push(`${blanks} خانة فارغة؛ أكملها قبل النشر أو اكتب — للخانات غير المنطبقة.`);
  return {columns,rows:grid,sizeHeader:(header[0]||'').slice(0,20),warnings};
}
/* Shrink a photo before upload: the server accepts up to 4 MB and larger pictures add no accuracy. */
function imageToDataUrl(file,maxSide=1600,quality=.88){
  return new Promise((resolve,reject)=>{
    if(!file||!/^image\/(png|jpe?g|webp)$/.test(file.type))return reject(new Error('استخدم صورة PNG أو JPEG أو WebP.'));
    const url=URL.createObjectURL(file),img=new Image();
    img.onload=()=>{
      const scale=Math.min(1,maxSide/Math.max(img.width,img.height)),canvas=document.createElement('canvas');
      canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));
      const context=canvas.getContext('2d');context.fillStyle='#fff';context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(img,0,0,canvas.width,canvas.height);
      URL.revokeObjectURL(url);resolve(canvas.toDataURL('image/jpeg',quality));
    };
    img.onerror=()=>{URL.revokeObjectURL(url);reject(new Error('تعذر قراءة الصورة.'));};img.src=url;
  });
}
/* "Complete the column": from the first two cells (90 then 94, or 86-90 then 90-94) continue the same step into the empty cells below. */
const digits=value=>String(value).trim().replace(/[٠-٩]/g,c=>'٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/[۰-۹]/g,c=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(c)).replace(/٫/g,'.');
function readCell(value){
  const m=digits(value).match(/^(\d+(?:\.\d+)?)(?:\s*([-–])\s*(\d+(?:\.\d+)?))?$/);if(!m)return null;
  const places=n=>(String(n).split('.')[1]||'').length;
  return {lo:Number(m[1]),hi:m[3]===undefined?Number(m[1]):Number(m[3]),range:m[3]!==undefined,dash:m[2]||'-',places:Math.max(places(m[1]),m[3]===undefined?0:places(m[3]))};
}
function fillSeries(values){
  const a=readCell(values[0]),b=readCell(values[1]);
  if(!a||!b||a.range!==b.range)return null;
  const stepLo=b.lo-a.lo,stepHi=a.range?b.hi-a.hi:stepLo;
  if(!stepLo&&!stepHi)return null;
  const places=Math.min(2,Math.max(a.places,b.places,...[stepLo,stepHi].map(x=>(String(Math.round(x*100)/100).split('.')[1]||'').length)));
  const show=n=>Number(n.toFixed(places)).toString(),out=values.slice();let filled=0;
  for(let i=2;i<out.length;i++){
    if(String(out[i]).trim()!=='')continue;
    const lo=a.lo+stepLo*i,hi=a.hi+stepHi*i;if(lo<0||hi<0)break;
    out[i]=a.range?show(lo)+a.dash+show(hi):show(lo);filled++;
  }
  return filled?{values:out,filled}:null;
}
/* Swap rows and columns: for a chart printed with the sizes across the top (or read that way by mistake). */
function transpose(grid){
  if(!grid||!grid.rows.length||!grid.columns.length)throw new Error('لا يوجد جدول لتبديله.');
  const sources=grid.rows.slice(0,MAX_COLUMNS),labels=unique(sources.map(r=>r.size||'')),warnings=[];
  if(grid.rows.length>MAX_COLUMNS)warnings.push(`بعد التبديل تُؤخذ أول ${MAX_COLUMNS} أعمدة فقط.`);
  if(grid.columns.length>MAX_ROWS)warnings.push(`بعد التبديل تُؤخذ أول ${MAX_ROWS} صفًا فقط.`);
  const rows=grid.columns.slice(0,MAX_ROWS).map((column,j)=>({size:String(column.label||'').slice(0,30),values:sources.map(r=>String(r.values[j]||'').slice(0,60))}));
  const columns=labels.map((label,i)=>{const cells=rows.map(r=>r.values[i]).filter(Boolean);return {label,kind:cells.length&&cells.every(c=>NUMERIC.test(c))?'measurement':'text'}});
  return {columns,rows,warnings};
}
window.SizeGuideImport={parseRows,toGrid,imageToDataUrl,fillSeries,transpose,MAX_COLUMNS,MAX_ROWS};
})();
