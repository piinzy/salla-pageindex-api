'use strict';
const $=s=>document.querySelector(s);
let stores=[],merchant='',page=1,pages=1,poll,timer,guideIndex=[],editing=null,guide=null,dirty=false,version=0,published=false,view='catalog',saving=false;
// An editor session is either one product's guide or a shared ("library") guide that many products follow.
let mode='product',libraryId=null,libraryName='',linkedTo=null,libraries=[],libraryProducts=[],pending=null,aiBlob=null,aiChecked=false;
const selected=new Set();
let savedStyles=[],savedPhrases=[],styleSnapshot=null,paletteUndo=null;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const url=s=>{try{let u=new URL(s);return u.protocol==='https:'?u.href:''}catch{return ''}};
const date=s=>s?new Date(s).toLocaleString('ar-SA',{dateStyle:'medium',timeStyle:'short'}):'لم تبدأ بعد';
const labels={sale:'معروض للبيع',hidden:'مخفي',out:'نفدت الكمية','out-and-notify':'نفدت مع التنبيه',queued:'في الانتظار',running:'قيد التنفيذ',success:'مكتملة',failed:'لم تكتمل'};
const Catalog=window.SizeGuideCatalog,UIX=window.SizeGuideUI,Import=window.SizeGuideImport;
const styleDefaults=Catalog?.styleDefaults||{category:'general',theme:'classic',table_style:'zebra',density:'comfortable',corners:'soft',depth3d:true,header_icon:true};
const withDefaults=g=>({...JSON.parse(JSON.stringify(styleDefaults)),...g});
const legacyTemplates={dresses:['محيط الصدر','محيط الخصر','محيط الأرداف','طول القطعة']};
const qs=()=>'?'+new URLSearchParams({merchant});
const mk=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n};
function fresh(templateId,category='general'){
  if(Catalog)return Catalog.fresh(templateId,category);
  const cols=legacyTemplates.dresses;
  return {...withDefaults({}),title:'دليل المقاسات',button_label:'دليل المقاسات',unit:'cm',measurement_type:'garment',columns:cols.map(label=>({label,kind:'measurement'})),rows:['S','M','L','XL'].map(size=>({size,values:cols.map(()=> '')})),notes:'',instructions:'',color:'#177e65'};
}
function toast(s){if(window.SizeGuideEmbedded?.toast(s))return;if(window.UIMotion?.toast(s))return;$('#toast').textContent=s;$('#toast').classList.remove('hidden');setTimeout(()=>$('#toast').classList.add('hidden'),7000)}
async function api(path,options={}){if(window.SizeGuideEmbedded)return window.SizeGuideEmbedded.request(path,options);let r=await fetch('/dashboard-api/'+path,{...options,headers:{'Content-Type':'application/json','X-Dashboard-Request':'1',...options.headers},cache:'no-store'});let d=await r.json();if(!r.ok){if(r.status===401&&!path.startsWith('login')){clearInterval(poll);poll=null;$('#app').classList.add('hidden');$('#login').classList.remove('hidden')}let detail=typeof d.detail==='string'?d.detail:Array.isArray(d.detail)?'راجعي حقول الجدول: '+d.detail.map(x=>x.msg).join('، '):'تعذر تنفيذ الطلب.';throw Error(detail)}return d}
async function confirmAction(message){return window.SizeGuideEmbedded?window.SizeGuideEmbedded.confirm(message):window.confirm(message)}
async function mayLeave(){if(saving||window.SizeGuideBatch?.busy()||window.SizeGuideSettings?.isBusy()){toast('انتظر اكتمال العملية أولًا.');return false}if(!dirty&&!window.SizeGuideSettings?.isDirty())return true;const confirmed=await confirmAction('لديك تعديلات غير محفوظة. هل تريد المغادرة دون حفظها؟');if(confirmed)window.SizeGuideSettings?.discard();return confirmed}
function show(tab){
  view=tab;if(tab==='buttonSettings')window.SizeGuideSettings?.load();
  if(tab==='home')loadHome().catch(()=>{});if(tab==='library')loadLibrary().catch(e=>toast(e.message));if(tab==='stats')loadStats().catch(e=>toast(e.message));if(tab==='catalog')loadRules().catch(()=>{});
  window.SizeGuideEmbedded?.navigate(tab);
  document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('hidden',t.id!==tab));
  document.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===(tab==='editor'?(mode==='library'?'library':'catalog'):tab)));
}
function touch(){dirty=true;$('#editState').textContent=(published?'يوجد جدول منشور · ':'مسودة · ')+'تعديلات غير محفوظة';syncColors()}
function changed(){touch();preview()}
function preview(){if(!guide)return;
  drawMeasurementReview();
  const theme=UIX.tokens(guide).theme;
  $('#previewThemeName').textContent=theme.name;
  const hints={
    stature:'لتفعيل اختيار القامة، أضف عمودًا نصيًا باسم «القامة» وحدّد الفئة لكل صف.',
    paired:'لتجميع المقاسات الرقمية تحت حرف واحد، أضف عمودًا نصيًا باسم «المقاس الحرفي» ورتّب صفوف كل حرف معًا.',
    sections:'تظهر أعمدة التحويل النصية وحقول القياس الرقمية في جدولين عند توفّر النوعين.',
    single:'تختار العميلة المقاس فتظهر قياسات الصف الذي أدخلته.',
    dualcols:'لكل حقل قياس عمودان، أحدهما بالسنتيمتر والآخر بالإنش.'
  };
  $('#themeGuideHint').textContent=hints[theme.mode]||'';
  $('#themeGuideHint').hidden=!hints[theme.mode];
  $('#previewProduct').textContent=editing?.title||guide.title;
  window.SizeGuideUI.preview($('#guidePreview'),guide,editing?.title||'',paintOn?{onPick:pickPart,selected:picked}:inlineEdit?{edit:editApi}:undefined)}

/* ---------- store, catalog and bulk actions ---------- */
async function boot(){
  await bootStores();
  // A dedicated Salla page can open straight on one tool: ...?view=quick
  const wanted=new URLSearchParams(location.search).get('view');if(wanted==='quick')show('catalog');else if(['home','catalog','batch','library','stats','buttonSettings'].includes(wanted))show(wanted);
  if(wanted==='buttonSettings' && new URLSearchParams(location.search).get('from')==='21'){
    requestAnimationFrame(()=>{if(view==='buttonSettings')window.SizeGuideSettings?.showNewDesigns();});
  }
}
async function bootStores(){window.SizeGuideBatch?.reset();stores=await api('stores');$('#store').innerHTML=stores.map(s=>`<option value="${esc(s.merchant_id)}">${esc(s.store_name===s.merchant_id?'متجر سلة • '+s.merchant_id:s.store_name)}</option>`).join('');$('#login').classList.add('hidden');$('#app').classList.remove('hidden');if(stores.length){merchant=$('#store').value;await load()}else{$('#sync').disabled=true;$('#empty').classList.remove('hidden');$('#empty').textContent='لا يوجد متجر مربوط. أعد إرسال رمز الوصول من تطبيق سلة.'}}
async function load(){let s=stores.find(s=>s.merchant_id===merchant);if(!s)return;setCount($('#count'),Number(s.product_count));$('#connection').textContent=s.connected?'متصل بسلة':'غير متصل';$('#merchant').textContent=merchant;$('#last').textContent=date(s.last_sync);guideIndex=await api('size-guides'+qs());await Promise.all([loadLibraryIndex(),loadPresets(),loadProducts(),loadJobs(),window.SizeGuideSettings?.load(),loadBilling(),loadRules().catch(()=>{})]);loadHome().catch(()=>{})}
function stateOf(g){
  if(!g)return ['بدون جدول',false];
  const base=g.is_published?(g.has_changes?'منشور + تعديلات مسودة':'منشور'):'مسودة';
  return [g.library_id?'مرتبط · '+(g.library_name||'جدول مشترك')+(g.is_published?'':' (غير منشور)'):base,!g.is_published];
}
async function loadProducts(){
  let current=merchant;let d=await api('products?'+new URLSearchParams({merchant,q:$('#filter').value,status:$('#status').value,guide:$('#guideFilter').value,page}));if(current!==merchant)return;pages=d.pages;
  $('#rows').innerHTML=d.items.map(p=>{
    const g=guideIndex.find(g=>g.product_id===p.product_id),[state,draft]=stateOf(g);
    return `<tr><td class="select-col"><input type="checkbox" data-select="${esc(p.product_id)}" ${selected.has(p.product_id)?'checked':''} aria-label="تحديد ${esc(p.title)}"></td><td><div class="product">${url(p.image)?`<img loading="lazy" src="${esc(url(p.image))}" alt="">`:'<div class="placeholder"></div>'}<div>${url(p.url)?`<a href="${esc(url(p.url))}" target="_blank" rel="noopener noreferrer">${esc(p.title)} ↗</a>`:esc(p.title)}<small dir="ltr">${esc(p.sku)||'#'+esc(p.product_id)}</small></div></div></td><td><span class="tag ${p.status!=='sale'?'warn':''}">${esc(labels[p.status]||p.status||'—')}</span></td><td><span class="tag ${draft?'badgeDraft':''}">${esc(state)}</span></td><td><div class="row-actions"><button class="secondary" data-edit="${esc(p.product_id)}">${g?(g.library_id?'عرض الجدول':'تعديل الجدول'):'إضافة مقاسات'}</button></div></td></tr>`;

  }).join('');
  $('#empty').classList.toggle('hidden',d.items.length>0);$('#empty').textContent=Number(stores.find(s=>s.merchant_id===merchant).product_count)?'لا توجد منتجات تطابق البحث.':'اضغط «مزامنة المنتجات» ثم أضف جدولًا للمنتج المطلوب.';
  $('#pageLabel').textContent=`${page} / ${pages} · ${d.total} منتج`;$('#prev').disabled=page<=1;$('#next').disabled=page>=pages;
  $('#rows').querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>openEditor(b.dataset.edit).catch(e=>toast(e.message)));
  $('#rows').querySelectorAll('[data-select]').forEach(box=>box.onchange=()=>{box.checked?selected.add(box.dataset.select):selected.delete(box.dataset.select);updateBulk()});
  updateBulk();
}
function updateBulk(){
  const boxes=[...document.querySelectorAll('#rows [data-select]')],on=boxes.filter(b=>b.checked).length;
  $('#bulkBar').classList.toggle('hidden',selected.size===0);$('#bulkCount').textContent=selected.size.toLocaleString('ar')+' منتج محدد';
  $('#selectAll').checked=boxes.length>0&&on===boxes.length;$('#selectAll').indeterminate=on>0&&on<boxes.length;
  $('#bulkSource').innerHTML='<option value="">اختر منتجًا له جدول…</option>'+guideIndex.map(g=>`<option value="${esc(g.product_id)}">${esc(g.title)}${g.sku?' • '+esc(g.sku):''}</option>`).join('');
  $('#bulkLibrary').innerHTML='<option value="">اختر جدولًا مشتركًا…</option>'+libraries.map(l=>`<option value="${esc(l.library_id)}">${esc(l.name)}</option>`).join('');
}
async function runBulk(path,body,message,summary){
  if(selected.size===0)return;if(message&&!(await confirmAction(message)))return;
  try{
    const data=await api(path+qs(),{method:'POST',body:JSON.stringify({...body,product_ids:[...selected]})});
    selected.clear();guideIndex=await api('size-guides'+qs());await Promise.all([loadProducts(),loadLibraryIndex()]);toast(summary(data));
  }catch(e){toast(e.message)}
}
const skippedNote=(list,hint)=>list.length?` · تخطي ${list.length}${hint?' ('+hint+')':''}`:'';
$('#selectAll').onchange=()=>{document.querySelectorAll('#rows [data-select]').forEach(b=>{b.checked=$('#selectAll').checked;b.checked?selected.add(b.dataset.select):selected.delete(b.dataset.select)});updateBulk()};
$('#bulkClear').onclick=()=>{selected.clear();document.querySelectorAll('#rows [data-select]').forEach(b=>b.checked=false);updateBulk()};
$('#bulkCopy').onclick=()=>{const source=$('#bulkSource').value;if(!source)return toast('اختر المنتج المصدر.');const overwrite=$('#bulkOverwrite').checked,publish=$('#bulkPublishCopy').checked;
  runBulk('size-guides/copy',{source_product_id:source,overwrite,publish},`نسخ الجدول إلى ${selected.size} منتج كنسخ مستقلة${publish?' ونشرها للعملاء':''}${overwrite?'، مع استبدال الجداول الموجودة':''}؟`,d=>`تم نسخ الجدول إلى ${d.copied.length} منتج`+skippedNote(d.skipped,overwrite?'':'لهم جدول؛ فعّل الاستبدال لتغييرها'))};
$('#bulkLink').onclick=()=>{const lib=$('#bulkLibrary').value;if(!lib)return toast('اختر الجدول المشترك.');
  runBulk('size-library/'+lib+'/link',{},`ربط ${selected.size} منتج بهذا الجدول المشترك؟ سيظهر لهم جدوله بدل جدولهم الحالي.`,d=>`تم ربط ${d.linked.length} منتج`+skippedNote(d.skipped))};
$('#bulkPublish').onclick=()=>runBulk('size-guides/bulk',{action:'publish'},`نشر مسودات المنتجات المحددة ليراها العملاء؟`,d=>`نُشر ${d.updated.length} جدول`+skippedNote(d.skipped,d.skipped[0]?.reason));
$('#bulkUnpublish').onclick=()=>runBulk('size-guides/bulk',{action:'unpublish'},`إيقاف ظهور جداول المنتجات المحددة مع الاحتفاظ بالمسودات؟`,d=>`أُوقف ظهور ${d.updated.length} جدول`+skippedNote(d.skipped,d.skipped[0]?.reason));
$('#bulkUnlink').onclick=()=>runBulk('size-guides/unlink',{},`فصل المنتجات المحددة عن الجدول المشترك؟ سيحتفظ كل منتج بنسخة مستقلة.`,d=>`تم فصل ${d.unlinked.length} منتج`+skippedNote(d.skipped,'غير مرتبطة'));
async function loadJobs(){let data=await api('jobs?'+new URLSearchParams({merchant}));$('#jobs').innerHTML=data.map(j=>`<tr><td>${date(j.started_at)}</td><td><span class="tag ${j.state==='failed'?'warn':''}">${esc(labels[j.state])}</span></td><td>${j.processed}${j.total!==null?' / '+j.total:''}</td><td style="white-space:normal;min-width:220px">${esc(j.message||'جارٍ جلب البيانات…')}</td></tr>`).join('')||'<tr><td colspan="4" class="empty">لم تُنفّذ أي مزامنة بعد.</td></tr>';let active=data.find(j=>['queued','running'].includes(j.state)&&Date.now()-new Date(j.started_at)<3600000);$('#sync').disabled=!!active;$('#syncState').classList.toggle('hidden',!active);if(active){$('#syncState').textContent=`المزامنة جارية · ${active.processed} منتج${active.total?' من '+active.total:''}`;if(!poll)poll=setInterval(()=>loadJobs().catch(e=>toast(e.message)),4000)}else if(poll){clearInterval(poll);poll=null;stores=await api('stores');await load();toast('انتهت المزامنة. راجع السجل لمعرفة النتيجة.')}}

/* ---------- library and statistics tabs ---------- */
async function loadLibraryIndex(){libraries=await api('size-library'+qs());if(!Array.isArray(libraries))libraries=[];updateBulk()}
async function loadLibrary(){
  await Promise.all([loadLibraryIndex(),loadRules().catch(()=>{})]);renderRules();const box=$('#libraryList');box.replaceChildren();$('#libraryEmpty').classList.toggle('hidden',libraries.length>0);
  for(const l of libraries){
    const card=mk('article','lib-card'),icon=mk('div','lib-emblem'),info=mk('div','lib-info'),chips=mk('div','chips'),actions=mk('div','bulk-buttons');
    if(UIX?.emblem){icon.style.color=Catalog?.defaults[l.category]?.color||'#177e65';icon.append(UIX.emblem(l.category||'general'))}
    chips.append(mk('span','tag '+(l.is_published?'':'badgeDraft'),l.is_published?(l.has_changes?'منشور + تعديلات مسودة':'منشور'):'مسودة'),mk('span','tag',Number(l.product_count).toLocaleString('ar')+' منتج'));
    info.append(mk('h3','',l.name),chips);const open=mk('button','','تعديل');open.type='button';open.onclick=()=>openLibrary(l.library_id).catch(e=>toast(e.message));actions.append(open);card.append(icon,info,actions);box.append(card);
  }
}
async function loadStats(){
  const days=Number($('#statsDays').value)||30,d=await api('size-guide-stats?'+new URLSearchParams({merchant,days}));
  const cards=[['فتح الجدول',d.opens],['استخدام «اعرف مقاسك»',d.calcs],['جداول منشورة',d.published_guides],['متوسط الفتح اليومي',(d.opens/days).toFixed(1)]];
  $('#statsCards').replaceChildren(...cards.map(([label,value])=>{const c=mk('article','card'),b=mk('b','',Number(value).toLocaleString('ar'));c.append(mk('label','',label),b);if(Number.isInteger(Number(value)))setCount(b,Number(value));return c}));
  const byDay=new Map(d.daily.map(x=>[String(x.day).slice(0,10),x.opens])),chart=$('#statsChart'),top=Math.max(1,...byDay.values());chart.replaceChildren();
  for(let i=days-1;i>=0;i--){const day=new Date(Date.now()-i*864e5).toISOString().slice(0,10),n=byDay.get(day)||0,bar=mk('span','bar');bar.style.height=Math.max(n?6:2,Math.round(n/top*100))+'%';bar.title=day+': '+n;chart.append(bar)}
  chart.setAttribute('aria-label',`رسم بياني: ${d.opens} فتحة للجدول خلال آخر ${days} يومًا`);
  $('#statsTop').innerHTML=d.top.map(t=>`<tr><td>${esc(t.title)}</td><td>${t.opens}</td><td>${t.calcs}</td></tr>`).join('')||'<tr><td colspan="3" class="empty">—</td></tr>';
  $('#statsEmpty').classList.toggle('hidden',d.opens+d.calcs>0);loadInsights().catch(()=>{});
}

/* ---- home: what needs attention, how the guides are used, where to start */
let homeStats=null,homeAlerts=0,homeLoading=false;
/* Numbers roll from the old value to the new one; where motion is unavailable they are simply set. */
function setCount(el,value,format){if(window.UIMotion)return window.UIMotion.rollTo(el,value,{format});el.textContent=format?format(value):Number(value).toLocaleString('ar')}
function renderPlan(){
  const b=billingState,card=$('#kpiPlan'),note=$('#kpiPlanNote');if(!card)return;
  if(!b){card.textContent='مفتوحة';note.textContent='بلا قيود حاليًا';$('#kpiMeterBox')?.classList.add('hidden');return}
  card.textContent=b.plan==='unlimited'?'كاملة':b.plan==='paid'?'مدفوعة':b.plan==='trial'?'تجربة مجانية':'منتهية';
  const meter=$('#kpiMeterBox');if(meter){const ai=b.ai,show=b.plan!=='unlimited'&&ai&&ai.limit>0;meter.classList.toggle('hidden',!show);if(show)window.UIMotion?.fill($('#kpiMeter'),(ai.plan_remaining)/ai.limit)}
  note.textContent=b.plan==='unlimited'?'غير محدودة':b.plan==='trial'?`باقي ${Number(b.trial_days_left).toLocaleString('ar')} يوم`:b.plan==='paid'?(b.paid_until?'حتى '+new Date(b.paid_until).toLocaleDateString('ar-SA',{dateStyle:'medium'}):'فعّالة'):'اشترك من صفحة التطبيق';
}
function renderHome(){
  if(!$('#home'))return;const n=x=>Number(x).toLocaleString('ar'),s=stores.find(x=>x.merchant_id===merchant);if(!s)return;
  const published=guideIndex.filter(g=>g.is_published).length,drafts=guideIndex.filter(g=>g.has_changes).length,missing=rulesData.missing||0,products=Number(s.product_count)||0;
  $('#heading').textContent='أهلاً بك'+(s.store_name&&s.store_name!==s.merchant_id?'، '+s.store_name:'');
  $('#kpiWith').textContent=products?`${n(Math.max(products-missing,0))} منها بجدول مقاسات`:'اضغط «مزامنة المنتجات» للبدء';
  setCount($('#kpiPublished'),published);$('#kpiDrafts').textContent=drafts?`${n(drafts)} فيها تعديلات غير منشورة`:'يراها العملاء الآن';
  homeStats?setCount($('#kpiOpens'),homeStats.opens):($('#kpiOpens').textContent='—');$('#kpiOpens').classList.toggle('sk',homeLoading&&!homeStats);$('#kpiCalcs').textContent=homeStats?`${n(homeStats.calcs)} استخدام لـ«اعرف مقاسك»`:'من العملاء في متجرك';
  const spark=$('#kpiSpark');if(spark&&window.UIMotion&&homeStats?.daily){const byDay=new Map(homeStats.daily.map(x=>[String(x.day).slice(0,10),x.opens])),values=[];for(let i=29;i>=0;i--)values.push(byDay.get(new Date(Date.now()-i*864e5).toISOString().slice(0,10))||0);const sig=values.join(',');if(spark.dataset.sig!==sig){spark.dataset.sig=sig;window.UIMotion.sparkline(spark,values,'اتجاه فتح الجدول خلال 30 يومًا')}}
  renderPlan();
  const steps=[[products>0,'زامن منتجاتك من سلة','يجلب أسماء المنتجات وصورها لتبدأ.',products>0?'':'مزامنة',()=>$('#sync').click()],
    [published>0,'أنشئ أول جدول مقاسات وانشره','اختر منتجًا، أو اصنع جدولًا مشتركًا لعدة منتجات.',published>0?'':'ابدأ',()=>show(libraries.length||products===0?'library':'catalog')],
    [!!window.SizeGuideSettings?.configured?.(merchant),'اضبط شكل الزر ومكانه','اختر تصميمه وموضعه في صفحة المنتج وجرّبه في المعاينة.','إعدادات الزر',()=>show('buttonSettings')]];
  $('#checklist').replaceChildren(...steps.map(([done,title,hint,action,go],i)=>{
    const li=mk('li',done?'done':''),mark=mk('span','mark',done?'✓':String(i+1)),text=mk('div','',''),strong=mk('strong','',title);text.append(strong,mk('small','',hint));li.append(mark,text);
    if(action){const b=mk('button','secondary small',action);b.type='button';b.dataset.nudge='forward';b.onclick=go;li.append(b)}return li}));
  const items=[];
  if(missing)items.push(['warn',`${n(missing)} منتج معروض بلا جدول مقاسات.`,'اعرضها',()=>{$('#guideFilter').value='none';page=1;show('catalog');loadProducts().catch(e=>toast(e.message))}]);
  if(homeAlerts)items.push(['warn',`${n(homeAlerts)} تنبيه عن مقاسات يرجعها العملاء كثيرًا.`,'راجعها',()=>show('stats')]);
  if(drafts)items.push(['info',`${n(drafts)} جدول فيه تعديلات لم تُنشر بعد.`,'افتح المنتجات',()=>show('catalog')]);
  if(billingState&&billingState.plan==='expired')items.push(['warn','انتهت التجربة أو الاشتراك: جداولك مخفية عن العملاء.','',null]);
  else if(billingState&&billingState.plan==='trial'&&billingState.trial_days_left<=2)items.push(['warn',`تنتهي تجربتك خلال ${n(billingState.trial_days_left)} يوم.`,'',null]);
  $('#attention').replaceChildren(...(items.length?items:[['ok','كل شيء على ما يرام. لا يوجد ما يحتاج عملًا الآن.','',null]]).map(([tone,text,action,go])=>{
    const li=mk('li',tone);li.append(mk('span','',text));if(action){const b=mk('button','secondary small',action);b.type='button';b.dataset.nudge='forward';b.onclick=go;li.append(b)}return li}));
  window.UIMotion?.enhance($('#home'));
}
window.addEventListener('guide-button-saved',renderHome);
async function loadHome(){
  homeLoading=true;renderHome();
  const [stats,insights]=await Promise.allSettled([api('size-guide-stats?'+new URLSearchParams({merchant,days:30})),api('size-insights?'+new URLSearchParams({merchant,days:90}))]);
  homeStats=stats.status==='fulfilled'?stats.value:null;homeAlerts=insights.status==='fulfilled'?(insights.value.alerts||[]).length:0;homeLoading=false;renderHome();
}
$('#homeSync').onclick=()=>$('#sync').click();
/* ---- products without a guide, and category rules */
let rulesData={rules:[],categories:[],missing:0,latest:[]};
const normalRules=d=>({rules:[],categories:[],missing:0,latest:[],...(d&&typeof d==='object'&&!Array.isArray(d)?d:{})});
async function loadRules(){rulesData=normalRules(await api('size-rules'+qs()));renderMissing();renderHome();if(!$('#library').classList.contains('hidden'))renderRules()}
function renderMissing(){
  const bar=$('#missingBar'),n=rulesData.missing||0;bar.replaceChildren();bar.classList.toggle('hidden',n===0);if(!n)return;
  bar.append(mk('span','',`${n.toLocaleString('ar')} منتج معروض بلا جدول مقاسات.`));
  const show=mk('button','secondary small','اعرضها');show.type='button';show.onclick=()=>{$('#guideFilter').value='none';page=1;loadProducts().catch(e=>toast(e.message))};bar.append(show);
  if(rulesData.rules.length){const apply=mk('button','small','اربطها حسب قواعد الفئات');apply.type='button';apply.onclick=applyRules;bar.append(apply)}
  else{const go=mk('button','secondary small','أنشئ قاعدة ربط تلقائي');go.type='button';go.onclick=()=>show_('library');bar.append(go)}
}
const show_=tab=>show(tab);
function renderRules(){
  const list=$('#rulesList'),build=()=>{list.replaceChildren();
  for(const r of rulesData.rules){
    const row=mk('div','rule-row'),text=mk('span','',`${r.category_name||r.category_id} (${(r.products||0).toLocaleString('ar')} منتج) ← ${r.library_name||'جدول محذوف'}`),del=mk('button','secondary small danger','حذف');
    del.type='button';del.setAttribute('aria-label','حذف قاعدة '+(r.category_name||r.category_id));del.onclick=async()=>{try{rulesData=normalRules(await api('size-rules/'+r.category_id+qs(),{method:'DELETE'}));renderMissing();renderRules()}catch(e){toast(e.message)}};row.dataset.key='r'+r.category_id;row.append(text,del);list.append(row);
  }
  if(!rulesData.rules.length)list.append(mk('p','micro','لا توجد قواعد بعد.'));};
  window.UIMotion?window.UIMotion.flip(list,build):build();
  const cat=$('#ruleCategory'),lib=$('#ruleLibrary');
  cat.replaceChildren(...(rulesData.categories.length?rulesData.categories:[{id:'',name:'لا توجد فئات: زامن المنتجات أولًا',products:0}]).map(c=>{const o=mk('option','',c.id?`${c.name||c.id} (${c.without_guide.toLocaleString('ar')} بلا جدول من ${c.products.toLocaleString('ar')})`:c.name);o.value=c.id;return o}));
  lib.replaceChildren(...(libraries.length?libraries:[{library_id:'',name:'أنشئ جدولًا مشتركًا أولًا'}]).map(l=>{const o=mk('option','',l.name);o.value=l.library_id;return o}));
  $('#ruleSave').disabled=!rulesData.categories.length||!libraries.length;$('#ruleApply').disabled=!rulesData.rules.length||!rulesData.missing;
}
$('#ruleSave').onclick=async()=>{try{rulesData=normalRules(await api('size-rules'+qs(),{method:'PUT',body:JSON.stringify({category_id:$('#ruleCategory').value,library_id:$('#ruleLibrary').value})}));renderMissing();renderRules();$('#ruleStatus').textContent='حُفظت القاعدة. اضغط «طبّق القواعد» لربط المنتجات الحالية.'}catch(e){toast(e.message)}};
async function applyRules(){
  try{const d=await api('size-rules/apply'+qs(),{method:'POST'});rulesData=normalRules(d);renderMissing();if(!$('#library').classList.contains('hidden'))renderRules();
    guideIndex=await api('size-guides'+qs());await Promise.all([loadProducts(),loadLibraryIndex()]);toast(d.linked?`رُبط ${d.linked.toLocaleString('ar')} منتج بجداول الفئات.`:'لا توجد منتجات تنطبق عليها القواعد.');$('#ruleStatus').textContent=''}catch(e){toast(e.message)}
}
$('#ruleApply').onclick=applyRules;
/* ---- sizes sold and sent back, from order events */
async function loadInsights(){
  const days=Number($('#insightDays').value)||90,d=await api('size-insights?'+new URLSearchParams({merchant,days})),n=x=>Number(x).toLocaleString('ar');
  const cards=[['قطع مباعة مرصودة',n(d.sold)],['قطع مرتجعة',n(d.returned)],['نسبة الإرجاع',Math.round(d.rate*100)+'%'],['الرصد منذ',d.since?new Date(d.since).toLocaleDateString('ar-SA',{dateStyle:'medium'}):'لم يبدأ']];
  $('#insightCards').replaceChildren(...cards.map(([label,value])=>{const c=mk('article','card');c.append(mk('label','',label),mk('b','',value));return c}));
  const alerts=$('#insightAlerts');alerts.replaceChildren();
  for(const a of d.alerts){const card=mk('article','insight-alert'),head=mk('strong','',a.title+(a.size?' · المقاس '+a.size:'')),body=mk('p','',a.message),open=mk('button','secondary small','فتح الجدول');open.type='button';open.onclick=()=>openEditor(a.product_id).catch(e=>toast(e.message));card.append(head,body,open);alerts.append(card)}
  $('#insightRows').replaceChildren(...d.products.map(p=>{const tr=mk('tr'),sizes=mk('td','','');for(const s of p.sizes.slice(0,8)){const chip=mk('span','size-chip'+(s.rate>=.25&&s.returned>=2?' warn':''),`${s.size}: ${n(s.sold)} / ${n(s.returned)}`);sizes.append(chip)}tr.append(mk('td','',p.title),sizes,mk('td','',Math.round(p.rate*100)+'%'));return tr}));
  $('#insightEmpty').classList.toggle('hidden',d.sold>0);
}
$('#insightDays').onchange=()=>loadInsights().catch(e=>toast(e.message));
$('#statsDays').onchange=()=>loadStats().catch(e=>toast(e.message));

/* ---------- editor: open, fill, save ---------- */
async function openEditor(id){
  if(!(await mayLeave()))return;const d=await api('size-guides/'+encodeURIComponent(id)+qs());
  lastSeen=d.last_seen_at;canRestore=false;mode='product';libraryId=null;libraryProducts=[];editing=d.product;linkedTo=d.library;guide=d.guide?withDefaults(d.guide):fresh();version=d.version;published=d.is_published;dirty=false;pending=null;
  fill();show('editor');$('#editor').scrollIntoView({behavior:'smooth',block:'start'});
}
async function openLibrary(id, importTable = false){
  if(!(await mayLeave()))return;mode='library';linkedTo=null;pending=null;
  canRestore=false;lastSeen=null;
  if(id){const d=await api('size-library/'+id+qs());libraryId=id;libraryName=d.name;canRestore=!!d.can_restore;guide=withDefaults(d.guide);version=d.version;published=d.is_published;libraryProducts=d.products}
  else{libraryId=null;libraryName='';guide=fresh();version=0;published=false;libraryProducts=[]}
  editing={title:libraryName||'جدول مشترك جديد'};dirty=false;fill();show('editor');$('#editor').scrollIntoView({behavior:'smooth',block:'start'});
  if(importTable){
    window.openEditorSection?.($('#importPanel'));
    $('#pasteTable').value='';
    $('#pasteTable').focus();
  }
}
let lastSeen=null,canRestore=false;
function showPublication(){
  const box=$('#publicationInfo');
  box.replaceChildren();
  $('#restoreLibrary').hidden=mode!=='library'||!canRestore;
  if(!published)return;
  const product=mode==='library'?libraryProducts.find(p=>p.url):editing;
  const productUrl=url(product?.url);
  if(productUrl){
    const link=mk('a','secondary',mode==='library'?'افتح منتجًا مرتبطًا في متجري':'افتح المنتج في متجري');
    link.href=productUrl;link.target='_blank';link.rel='noopener noreferrer';box.append(link);
  }
  if(mode!=='product')return;
  const status=mk('span','micro',lastSeen?'آخر ظهور مرصود للزر: '+date(lastSeen):'بانتظار رصد ظهور الزر على صفحة المنتج.');
  const refresh=mk('button','secondary small','تحديث حالة الظهور');
  refresh.type='button';
  refresh.onclick=async()=>{
    const current=editing,store=merchant;
    refresh.disabled=true;
    try{
      const d=await api('size-guides/'+encodeURIComponent(current.product_id)+qs());
      if(current===editing&&store===merchant){lastSeen=d.last_seen_at;showPublication()}
    }catch(e){toast(e.message)}finally{refresh.disabled=false}
  };
  box.append(status,refresh);
}
$('#restoreLibrary').onclick=async()=>{
  if(saving||!canRestore||!libraryId)return;
  if(!await confirmAction(`استعادة النسخة المنشورة السابقة لـ ${libraryProducts.length} منتج مرتبط؟ ستستبدل المسودة الحالية أيضًا.`))return;
  saving=true;
  try{
    await api('size-library/'+libraryId+'/restore'+qs(),{method:'POST',body:JSON.stringify({version})});
    dirty=false;saving=false;await openLibrary(libraryId);toast('تمت استعادة النسخة المنشورة السابقة.');
  }catch(e){toast(e.message)}finally{saving=false}
};
function applyMode(){
  showPublication();
  const library=mode==='library';
  document.querySelectorAll('#editor .only-library').forEach(n=>n.classList.toggle('hidden',!library));document.querySelectorAll('#editor .only-product').forEach(n=>n.classList.toggle('hidden',library));
  $('#editorKind').textContent=library?'جدول مشترك':'تحرير دليل المنتج';$('#deleteLibrary').classList.toggle('hidden',!library||!libraryId);
  $('#editFields').disabled=!!linkedTo;$('#linkedBanner').classList.toggle('hidden',!linkedTo);$('#linkedName').textContent=linkedTo?.name||'';
  $('#saveNote').textContent=library?'نشر الجدول المشترك يحدّث كل المنتجات المرتبطة به فورًا؛ حفظ المسودة لا يغيّر ما يراه العملاء.':'حفظ المسودة لا يغيّر النسخة المنشورة. الزر يظهر فقط لمنتج له جدول منشور.';
  $('#libraryName').value=libraryName;$('#linkHint').textContent=libraryId?'ابحث عن المنتجات التي تريد أن تتبع هذا الجدول.':'احفظ الجدول أولًا ثم اربط المنتجات.';
  $('#linkSearch').disabled=!libraryId;$('#linkSelected').disabled=!libraryId;
}
function renderLibraryProducts(){
  const box=$('#libraryProducts');box.replaceChildren();if(mode!=='library')return;
  box.append(mk('strong','',libraryProducts.length?`المنتجات المرتبطة (${libraryProducts.length})`:'لا توجد منتجات مرتبطة بعد.'));
  for(const p of libraryProducts){
    const row=mk('div','link-row'),text=mk('span','',p.title+(p.sku?' • '+p.sku:'')),remove=mk('button','secondary small','فصل');remove.type='button';remove.setAttribute('aria-label','فصل '+p.title);
    remove.onclick=async()=>{if(!(await confirmAction('فصل هذا المنتج؟ سيحتفظ بنسخة مستقلة من الجدول الحالي.')))return;try{await api('size-guides/unlink'+qs(),{method:'POST',body:JSON.stringify({product_ids:[p.product_id]})});await reloadLibraryProducts();toast('تم فصل المنتج.')}catch(e){toast(e.message)}};
    row.append(text,remove);box.append(row);
  }
}
async function reloadLibraryProducts(){if(!libraryId)return;const d=await api('size-library/'+libraryId+qs());libraryProducts=d.products;guideIndex=await api('size-guides'+qs());renderLibraryProducts();renderLinkResults()}
let linkCandidates=[];
async function searchLinkable(){
  if(!libraryId)return;const d=await api('products?'+new URLSearchParams({merchant,q:$('#linkSearch').value,page:1}));
  linkCandidates=d.items.filter(p=>!libraryProducts.some(x=>x.product_id===p.product_id));renderLinkResults();
}
function renderLinkResults(){
  const box=$('#linkResults');box.replaceChildren();if(!libraryId)return;
  const keep=linkCandidates.filter(p=>!libraryProducts.some(x=>x.product_id===p.product_id));
  if(!keep.length){box.append(mk('p','micro','ابحث لتظهر المنتجات القابلة للربط.'));return}
  for(const p of keep){const label=mk('label','check'),box1=mk('input');box1.type='checkbox';box1.value=p.product_id;label.append(box1,document.createTextNode(' '+p.title+(p.sku?' • '+p.sku:'')));box.append(label)}
}
$('#linkSearch').oninput=()=>{clearTimeout(timer);timer=setTimeout(()=>searchLinkable().catch(e=>toast(e.message)),300)};
$('#linkPicker').addEventListener('toggle',()=>{if($('#linkPicker').open&&libraryId)searchLinkable().catch(e=>toast(e.message))});
$('#linkSelected').onclick=async()=>{
  const ids=[...document.querySelectorAll('#linkResults input:checked')].map(i=>i.value);if(!ids.length)return toast('حدد منتجًا واحدًا على الأقل.');
  if(published&&!(await confirmAction('سيظهر هذا الجدول المنشور فورًا لعملاء المنتجات المحددة. هل تتابع؟')))return;
  try{const d=await api('size-library/'+libraryId+'/link'+qs(),{method:'POST',body:JSON.stringify({product_ids:ids})});await reloadLibraryProducts();toast(`تم ربط ${d.linked.length} منتج`+skippedNote(d.skipped))}catch(e){toast(e.message)}
};
$('#libraryName').oninput=()=>{libraryName=$('#libraryName').value;if(editing)editing.title=libraryName||'جدول مشترك جديد';$('#editorTitle').textContent=editing.title;dirty=true;$('#editState').textContent=(published?'يوجد جدول منشور · ':'مسودة · ')+'تعديلات غير محفوظة'};
$('#openLibraryFromProduct').onclick=()=>openLibrary(linkedTo.library_id).catch(e=>toast(e.message));
$('#unlinkThis').onclick=async()=>{
  if(!linkedTo||!(await confirmAction('فصل هذا المنتج؟ سيحتفظ بنسخة مستقلة من الجدول المشترك الحالي ويمكنك تعديلها بحرية.')))return;
  try{await api('size-guides/unlink'+qs(),{method:'POST',body:JSON.stringify({product_ids:[editing.product_id]})});dirty=false;toast('تم فصل المنتج.');await openEditor(editing.product_id)}catch(e){toast(e.message)}
};
$('#importLibrary').onclick=()=>openLibrary(null,true).catch(e=>toast(e.message));
$('#newLibrary').onclick=()=>openLibrary(null).catch(e=>toast(e.message));
$('#deleteLibrary').onclick=async()=>{
  if(!libraryId||!(await confirmAction('حذف هذا الجدول المشترك نهائيًا؟ لا يمكن حذفه وهو مرتبط بمنتجات.')))return;
  try{await api('size-library/'+libraryId+qs(),{method:'DELETE'});dirty=false;toast('حُذف الجدول المشترك.');show('library')}catch(e){toast(e.message)}
};
/* ---------- faster data entry: complete a column, paste a block of cells ---------- */
function fillColumn(index){
  const result=Import?.fillSeries(guide.rows.map(r=>r.values[index]));
  if(!result)return toast('اكتب رقمين مختلفين في أول صفين من العمود (مثل 90 ثم 94)، وتأكد أن بقية الخانات فارغة.');
  guide.rows.forEach((r,i)=>r.values[index]=result.values[i]);drawGrid();changed();toast(`تمت تعبئة ${result.filled} خانة بنفس الفرق. راجع الأرقام.`);
}
$('#gridEditor').addEventListener('paste',event=>{
  const target=event.target,text=event.clipboardData?.getData('text')||'';
  if(!guide||!Import||!/[\t\n\r]/.test(text.trim()))return;                       // one value pastes normally
  const rows=Import.parseRows(text),row0=target.dataset.size!==undefined?+target.dataset.size:target.dataset.row!==undefined?+target.dataset.row:-1;
  if(row0<0||(rows.length===1&&rows[0].length===1))return;
  event.preventDefault();const col0=target.dataset.size!==undefined?-1:+target.dataset.cell;let cells=0,dropped=0;
  rows.forEach((line,a)=>{
    const i=row0+a;if(i>=30){dropped+=line.length;return}
    while(guide.rows.length<=i)guide.rows.push({size:'',values:guide.columns.map(()=> '')});
    line.forEach((cell,k)=>{const col=col0+k;if(col===-1)guide.rows[i].size=cell.slice(0,30);else if(col>=0&&col<guide.columns.length)guide.rows[i].values[col]=cell.slice(0,60);else{dropped++;return}cells++});
  });
  drawGrid();changed();toast(`لُصقت ${cells} خانة`+(dropped?` وتُجوهلت ${dropped} خارج حدود الجدول`:'')+'.');
});
/* ---------- looks: ready-made styles, the store's colour, saved designs and phrases ---------- */
async function loadPresets(){
  try{const d=await api('size-presets'+qs());savedStyles=Array.isArray(d?.styles)?d.styles:[];savedPhrases=Array.isArray(d?.phrases)?d.phrases:[]}catch{savedStyles=[];savedPhrases=[]}
}
const styleOf=g=>Object.fromEntries((Catalog?.STYLE_FIELDS||[]).filter(k=>k in g).map(k=>[k,g[k]]));
function miniTable(style){
  const full={...style};if(!/^#[0-9a-fA-F]{6}$/.test(full.color||''))full.color=UIX.tokens(full).theme.accent;
  const pal=UIX.palette(full),box=mk('div','preset-mini');
  for(const [k,v] of Object.entries({head:pal.headBg,headInk:pal.headInk,alt:pal.alt,line:pal.line,paper:pal.paper,chip:pal.chipBg,chipInk:pal.chipInk,accent:pal.accent}))box.style.setProperty('--m-'+k,v);
  Object.assign(box.dataset,{size:style.size_style||'chip',border:style.border_style||'thin',corners:style.corners||'soft',table:style.table_style||'zebra',head:pal.headStyle});
  const head=mk('div','m-row m-head');head.append(mk('i'),mk('i'),mk('i'));box.append(head);
  for(let r=0;r<3;r++){const row=mk('div','m-row');row.append(mk('b','m-chip'),mk('i'),mk('i'));box.append(row)}
  return box;
}
function renderPresets(){
  if(!UIX?.palette||!Catalog)return;
  const draw=(box,items,saved)=>{
    box.replaceChildren();
    for(const item of items){
      const card=mk('div','preset-card'),pick=mk('button','preset-pick');pick.type='button';pick.title=item.hint||item.name;pick.append(miniTable(item.style),mk('span','',item.name));
      pick.onclick=()=>applyStyle(item.style,item.name);card.append(pick);
      if(saved){const x=mk('button','preset-x','×');x.type='button';x.setAttribute('aria-label','حذف التصميم '+item.name);x.onclick=()=>removePreset(item.preset_id,item.name,'styles');card.append(x)}
      box.append(card);
    }
  };
  draw($('#presetChoices'),Catalog.stylePresets,false);$('#presetChoices').classList.toggle('hidden',!Catalog.stylePresets.length);
  draw($('#myPresets'),savedStyles.map(p=>({...p,style:p.style})),true);
  $('#myPresetsTitle').classList.toggle('hidden',savedStyles.length===0);$('#myPresets').classList.toggle('hidden',savedStyles.length===0);
}
$('#guideFont').onchange=()=>{guide.font_family=$('#guideFont').value;changed()};
function applyStyle(style,label){
  if(!guide)return;styleSnapshot=styleOf(guide);
  const next={...style};if(!/^#[0-9a-fA-F]{6}$/.test(next.color||''))next.color=UIX.tokens(next).theme.accent;
  Object.assign(guide,styleOf(next));$('#guideColor').value=guide.color;syncChoices();changed();$('#undoStyle').classList.remove('hidden');toast('طُبّق النمط: '+label+'. جدولك لم يتغير.');
}
$('#undoStyle').onclick=()=>{if(!styleSnapshot||!guide)return;Object.assign(guide,styleSnapshot);styleSnapshot=null;$('#guideColor').value=guide.color;syncChoices();changed();$('#undoStyle').classList.add('hidden')};
const brandKey=()=>'sg-brand-'+merchant;
function rememberedBrand(){try{return localStorage.getItem(brandKey())||''}catch{return ''}}
$('#applyBrand').onclick=()=>{
  if(!guide)return;const hex=$('#brandColor').value,result=UIX.brandStyle(hex,UIX.palette(guide).paper);if(!result)return toast('اختر لونًا صالحًا.');
  styleSnapshot=styleOf(guide);guide.color=result.color;guide.header_style=result.header_style;for(const k of ['header_bg','header_text','row_alt','size_bg','size_text'])guide[k]='';
  try{localStorage.setItem(brandKey(),hex)}catch{/* optional convenience only */}
  $('#guideColor').value=guide.color;syncChoices();changed();$('#undoStyle').classList.remove('hidden');
  toast(result.adjusted?'عُدِّل اللون قليلًا ليكون مقروءًا على خلفية الجدول.':'طُبّق لون متجرك على الجدول.');
};
$('#savePreset').onclick=async()=>{
  const name=$('#presetName').value.trim();if(!guide)return;if(!name)return toast('اكتب اسمًا لتصميمك أولًا.');
  try{const d=await api('size-presets'+qs(),{method:'POST',body:JSON.stringify({kind:'style',name,style:styleOf(guide)})});savedStyles.push(d);$('#presetName').value='';renderPresets();toast('حُفظ التصميم «'+name+'» ويمكنك تطبيقه على أي جدول.')}catch(e){toast(e.message)}
};
async function removePreset(id,name,kind){
  if(!(await confirmAction('حذف «'+name+'» نهائيًا؟')))return;
  try{await api('size-presets/'+id+qs(),{method:'DELETE'});if(kind==='styles')savedStyles=savedStyles.filter(p=>p.preset_id!==id);else savedPhrases=savedPhrases.filter(p=>p.preset_id!==id);renderPresets();renderPhrases()}catch(e){toast(e.message)}
}
function renderPhrases(){
  const box=$('#phraseChips');box.replaceChildren();if(!guide)return;
  const add=(text,id)=>{
    const chip=mk('span','phrase-chip'),pick=mk('button','phrase-pick',text.length>44?text.slice(0,44)+'…':text);pick.type='button';pick.title=text;pick.onclick=()=>addPhrase(text);chip.append(pick);
    if(id){const x=mk('button','preset-x','×');x.type='button';x.setAttribute('aria-label','حذف الجملة');x.onclick=()=>removePreset(id,text.slice(0,30),'phrases');chip.append(x)}
    box.append(chip);
  };
  for(const text of Catalog?.phrasesFor(guide.category)||[])add(text);for(const p of savedPhrases)add(p.text,p.preset_id);
}
function addPhrase(text){
  const current=$('#notes').value;if(current.includes(text))return toast('هذه الجملة موجودة في الملاحظات.');
  const next=current.trim()?current.replace(/\s+$/,'')+'\n'+text:text;if(next.length>2000)return toast('الملاحظات ستتجاوز 2000 حرف.');
  $('#notes').value=next;guide.notes=next;changed();
}
$('#savePhrase').onclick=async()=>{
  const text=$('#phraseText').value.trim();if(!text)return toast('اكتب الجملة أولًا.');
  try{const d=await api('size-presets'+qs(),{method:'POST',body:JSON.stringify({kind:'phrase',name:text.slice(0,40),text})});savedPhrases.push(d);$('#phraseText').value='';renderPhrases();toast('حُفظت الجملة.')}catch(e){toast(e.message)}
};
function fill(){
  paletteUndo=null;$('#paletteIncludePaint').checked=true;
  for(const [id,key] of [['guideTitle','title'],['buttonLabel','button_label'],['guideUnit','unit'],['measureType','measurement_type'],['guideColor','color'],['instructions','instructions'],['notes','notes']])$('#'+id).value=guide[key];
  $('#editorTitle').textContent=mode==='library'?(libraryName||'جدول مشترك جديد'):editing.title+(editing.sku?' • '+editing.sku:'');
  $('#editState').textContent=linkedTo?'هذا الجدول يتبع الجدول المشترك؛ التعديل من هناك.':published?'الجدول منشور للعميل؛ حفظ المسودة لا يغيّره.':version?'مسودة محفوظة؛ لا تظهر للعميل.':'جدول جديد؛ لم يُحفظ بعد.';
  $('#unpublish').disabled=!published;
  $('#copyFrom').innerHTML='<option value="">اختر المنتج المصدر…</option>'+guideIndex.filter(g=>g.product_id!==editing.product_id).map(g=>`<option value="${esc(g.product_id)}">${esc(g.title)} ${g.sku?'• '+esc(g.sku):''}</option>`).join('');
  applyMode();fillTemplates();renderThemes();syncChoices();syncAdvanced();styleSnapshot=null;picked=null;syncPaint();$('#undoStyle').classList.add('hidden');$('#brandColor').value=rememberedBrand()||guide.color;renderPresets();renderPhrases();renderLibraryProducts();renderLinkResults();hidePending();drawGrid();preview();
}
function fillTemplates(){
  if(!Catalog){$('#template').innerHTML='<option value="dresses">هيكل فساتين</option>';return}
  const order=['general','women','men','kids','shoes','pets','accessories'],names=Object.fromEntries((UIX?.categories||[]).map(c=>[c.id,c.name]));
  $('#template').innerHTML=order.map(cat=>{const list=Catalog.forCategory(cat);return list.length?`<optgroup label="${esc(names[cat]||cat)}">${list.map(t=>`<option value="${esc(t.id)}">${esc('هيكل '+t.name)}</option>`).join('')}</optgroup>`:''}).join('');
  const own=Catalog.forCategory(guide.category)[0];if(own)$('#template').value=own.id;
}
function renderThemes(){
  const box=$('#themeChoices');box.replaceChildren();if(!UIX||!guide)return;
  for(const theme of UIX.themes){
    const label=mk('label','theme-card'),radio=mk('input');
    radio.type='radio';radio.name='guide-theme';radio.value=theme.id;
    label.append(radio,miniTable({theme:theme.id,color:theme.accent,size_style:'plain',header_style:theme.head}),mk('span','',theme.name));
    label.dataset.presentation=theme.mode;
    radio.onchange=()=>{
      if(!radio.checked)return;
      const previous=UIX.tokens(guide).theme;
      applyStyle({theme:theme.id,color:guide.color===previous.accent?theme.accent:guide.color,
        layout_type:['howfirst','howlast','systems','sections','paired'].includes(theme.mode)?'page':theme.mode==='fit'?'tabs':guide.layout_type,
        header_icon:false,depth3d:false,corners:'sharp',size_style:'plain'},theme.name);
    };
    box.append(label);
  }
}
for(const button of document.querySelectorAll('[data-guide-device]')){
  button.onclick=()=>{
    $('#guideViewport').dataset.device=button.dataset.guideDevice;
    document.querySelectorAll('[data-guide-device]').forEach(item=>item.setAttribute('aria-pressed',String(item===button)));
  };
}
$('#expandGuidePreview').onclick=()=>{if(guide)UIX.open(guide,editing?.title||'')};
/* Radio groups drawn as segmented controls; every group edits one field of the guide. */
const SEGMENTS=[
  ['tableStyleSeg','table_style',[['zebra','مخطط'],['lines','خطوط'],['cards','بطاقات'],['plain','بسيط']]],
  ['densitySeg','density',[['comfortable','مريح'],['compact','مدمج']]],
  ['cornersSeg','corners',[['sharp','حادة'],['soft','ناعمة'],['round','دائرية']]],
  ['sizeStyleSeg','size_style',[['chip','شارة مجسمة'],['pill','كبسولة'],['square','مربع'],['underline','خط سفلي'],['plain','نص فقط']]],
  ['headerStyleSeg','header_style',[['auto','حسب الثيم'],['tint','هادئة'],['solid','ممتلئة'],['plain','شفافة'],['line','بخط']]],
  ['borderStyleSeg','border_style',[['auto','حسب الثيم'],['none','بلا'],['thin','رفيعة'],['strong','سميكة']]],
  ['fontScaleSeg','font_scale',[['small','صغير'],['medium','متوسط'],['large','كبير']]],
  ['layoutSeg','layout_type',[['tabs','تبويبات'],['page','صفحة واحدة'],['cards','بطاقات'],['compact','جدول فقط']]],
  ['fitSeg','fit_level',[['','بدون'],['slim','ضيقة'],['regular','عادية'],['loose','واسعة']]],
  ['sideLayoutSeg','side_layout',[['auto','تلقائي'],['none','بدون'],['start','قبل الجدول'],['end','بعد الجدول']]],
  ['howArtSeg','how_art',[['auto','حسب الفئة'],['women','نسائي'],['men','رجالي'],['kids','أطفال'],['none','بدون']]],
  ['languageSeg','language',[['ar','العربية'],['en','English'],['auto','حسب المتجر']]],
];
const COLOR_FIELDS=[['header_bg','headBg','خلفية الترويسة'],['header_text','headInk','نص الترويسة'],['row_alt','alt','الصفوف المتبادلة'],['border_color','line','الحدود'],
  ['text_color','ink','نص الجدول'],['paper_color','paper','خلفية الجدول'],['size_bg','chipBg','خلفية خانة المقاس'],['size_text','chipInk','نص خانة المقاس']];
const paletteKeys=['color',...COLOR_FIELDS.map(([key])=>key)];
const hasPaintColors=part=>Boolean(part.bg||part.fg);
function currentColors(){
  return Object.fromEntries(paletteKeys.map(key=>[key,guide[key]||'']));
}
function paletteMatches(colors){
  return paletteKeys.every(key=>(guide[key]||'').toLowerCase()===colors[key].toLowerCase());
}
function paintLocationState(){
  // Avoid restoring color rules to a different row or column after grid edits.
  return JSON.stringify([guide.rows.map(row=>row.size),guide.columns,guide.cell_styles]);
}
function applyPalette(item){
  if(!guide)return;
  const paint=guide.cell_styles||[];
  const replacePaint=$('#paletteIncludePaint').checked && paint.some(hasPaintColors);
  if(!replacePaint && paletteMatches(item.colors))return;
  const previous=currentColors();
  if(replacePaint){
    guide.cell_styles=paint.map(({bg,fg,...rule})=>rule).filter(rule=>rule.bold||rule.align);
  }
  Object.assign(guide,item.colors);
  paletteUndo={previous,applied:item.colors,paint:replacePaint?paint:null,
    locations:replacePaint?paintLocationState():null};
  styleSnapshot=null;$('#undoStyle').classList.add('hidden');
  $('#guideColor').value=guide.color;
  syncPaint();changed();
  toast('طُبّقت لوحة «'+item.name+'» على الجدول.');
}
function buildPaletteChoices(){
  const choices=$('#guidePalettes');choices.replaceChildren();
  for(const item of Catalog?.colorPalettes||[]){
    const button=mk('button','guide-palette'),sample=mk('span','palette-mini');
    button.type='button';button.dataset.palette=item.id;button.setAttribute('aria-pressed','false');
    sample.setAttribute('aria-hidden','true');
    const {vars}=UIX.tokens(item.colors);
    for(const [key,value] of Object.entries(vars))sample.style.setProperty(key,value);
    for(const value of ['المقاس','الصدر','الخصر','S','88','68','M','92','72'])sample.append(mk('span','',value));
    button.append(sample,mk('span','palette-name',item.name));button.onclick=()=>applyPalette(item);
    choices.append(button);
  }
}
function syncPaletteChoices(){
  for(const item of Catalog?.colorPalettes||[]){
    $('#guidePalettes [data-palette="'+item.id+'"]')?.setAttribute('aria-pressed',String(paletteMatches(item.colors)));
  }
  $('#palettePaintOption').hidden=!(guide.cell_styles||[]).some(hasPaintColors);
  if(paletteUndo && (!paletteMatches(paletteUndo.applied) || (paletteUndo.paint && paletteUndo.locations!==paintLocationState())))paletteUndo=null;
  $('#undoPalette').hidden=!paletteUndo;
}
$('#undoPalette').onclick=()=>{
  if(!guide||!paletteUndo)return;
  const {previous,paint}=paletteUndo;paletteUndo=null;
  Object.assign(guide,previous);if(paint)guide.cell_styles=paint;
  $('#guideColor').value=guide.color;syncPaint();changed();
};
/* Flat one-colour line icons for the category picker (the 3D emblems stay on the storefront header). */
const LINE_ICONS={general:'<path d="M4 9h16v6H4zM8 9v3M12 9v2M16 9v3"/>',women:'<path d="M9 3l-2 4 2 3-3 11h12l-3-11 2-3-2-4-3 2z"/>',men:'<path d="M8 4l-5 3 2 5 3-1v9h8v-9l3 1 2-5-5-3q-2 2-4 2T8 4z"/>',
  kids:'<path d="M9 5L4 8l1 4 3-1v9h8v-9l3 1 1-4-5-3q-2 2-6 0z"/><path d="M12 11.500l.9 1.800 2 .3-1.450 1.400.35 2-1.800-.950-1.800.950.35-2L9.100 13.600l2-.3z"/>',shoes:'<path d="M3 15v-4l4-1 3-4 3 2h3q4 1 5 6v2H4z"/><path d="M3 18h18"/>',
  pets:'<circle cx="6" cy="11" r="1.8"/><circle cx="10" cy="6.500" r="1.8"/><circle cx="14.500" cy="6.500" r="1.8"/><circle cx="18.500" cy="11" r="1.8"/><path d="M12 12c-3 0-5.500 2.500-5.500 5 0 2 1.700 2.800 3.200 2.500 1-.2 1.600-.6 2.300-.6s1.300.4 2.300.6c1.500.3 3.200-.5 3.200-2.500 0-2.500-2.500-5-5.500-5z"/>',
  accessories:'<circle cx="12" cy="15" r="6"/><path d="M9 4l-1.500 3h9L15 4z"/>'};
function catIcon(id){const d=LINE_ICONS[id]||LINE_ICONS.general,svg=new DOMParser().parseFromString(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`,'image/svg+xml');return document.importNode(svg.documentElement,true)}
const SPECIAL=['general','shoes','pets','accessories'],groupOf=id=>SPECIAL.includes(id)?'special':id;
function buildChoices(){
  buildPaletteChoices();
  const box=$('#categoryChoices');box.replaceChildren();
  const names=Object.fromEntries((UIX?.categories||[]).map(c=>[c.id,c.name]));
  const tiles=[['women','نسائي'],['men','رجالي'],['kids','أطفال'],['special','خاص']];
  for(const [id,name] of tiles){
    const label=mk('label','cat-card'),radio=mk('input'),icon=mk('span','cat-icon'),ico=catIcon(id==='special'?'general':id);radio.type='radio';radio.name='guide-category';radio.value=id;radio.setAttribute('aria-label',name);
    label.style.setProperty('--cat',Catalog?.defaults[id==='special'?'general':id]?.color||'#177e65');icon.append(ico);label.append(radio,icon,mk('span','cat-name',name),mk('span','cat-check','✓'));
    radio.onchange=()=>{if(radio.checked)setCategory(id==='special'?(SPECIAL.includes(guide?.category)?guide.category:'general'):id)};box.append(label);
  }
  const special=$('#specialType');special.replaceChildren(...SPECIAL.map(id=>{const o=mk('option','',names[id]||id);o.value=id;return o}));special.onchange=()=>setCategory(special.value);
  for(const [id,key,options] of SEGMENTS){
    const group=$('#'+id);group.replaceChildren();
    for(const [value,text] of options){const label=mk('label'),radio=mk('input');radio.type='radio';radio.name='guide-'+key;radio.value=value;label.append(radio,mk('span','',text));group.append(label);radio.onchange=()=>{if(radio.checked&&guide){guide[key]=value;syncChoices();changed()}}}
  }
  const colors=$('#tableColors');colors.replaceChildren();
  for(const [key,,title] of COLOR_FIELDS){
    const field=mk('div','color-field'),label=mk('label','',title),input=mk('input'),status=mk('small','','تلقائي'),reset=mk('button','secondary small','×');
    input.type='color';input.id='tc-'+key;label.htmlFor=input.id;status.id='tc-status-'+key;input.setAttribute('aria-describedby',status.id);reset.type='button';reset.setAttribute('aria-label','إعادة '+title+' إلى تلقائي');
    input.oninput=()=>{if(!guide)return;guide[key]=input.value;changed()};
    reset.onclick=()=>{if(!guide)return;guide[key]='';changed()};
    field.append(label,input,status,reset);colors.append(field);
  }
}
const LAYOUT_HINTS={tabs:'ثلاثة تبويبات: الجدول وطريقة القياس واعرف مقاسك.',page:'صفحة واحدة: الجدول أولًا، وتحته قسمان قابلان للطي لطريقة القياس واعرف مقاسك.',cards:'بطاقة لكل مقاس، مناسبة للجوال. التلوين بالنقر يعمل مع الجدول لا مع البطاقات.',compact:'الجدول وحده بلا تبويبات ولا طريقة قياس.'};
function syncChoices(){if(guide){$('#guideFont').value=guide.font_family||'';if($('#sysChecks'))syncSystems()}
  if(!guide)return;
  for(const [name,value] of [['guide-category',groupOf(guide.category)],['guide-theme',guide.theme],...SEGMENTS.map(([,key])=>['guide-'+key,guide[key]])])
    document.querySelectorAll(`#editor [name="${name}"]`).forEach(r=>{r.checked=r.value===value;r.closest('label').classList.toggle('selected',r.checked)});
  $('#specialRow').classList.toggle('hidden',!SPECIAL.includes(guide.category));$('#specialType').value=guide.category;
  $('#layoutHint').textContent=LAYOUT_HINTS[guide.layout_type]||LAYOUT_HINTS.tabs;syncInlineEdit();
  $('#side3d').checked=guide.side_3d===true;
  $('#depth3d').checked=guide.depth3d!==false;$('#headerIcon').checked=guide.header_icon!==false;
}
/* Colour pickers show the colour in effect: the merchant's own, or the one the theme would use. */
function syncColors(){
  if(!guide)return;syncPaletteChoices();const pal=UIX?.palette?.(guide);
  for(const [key,prop] of COLOR_FIELDS){
    const input=$('#tc-'+key);if(!input)continue;const own=/^#[0-9a-fA-F]{6}$/.test(guide[key]||'');
    input.value=own?guide[key]:(pal?.[prop]||'#000000');$('#tc-status-'+key).textContent=own?'مخصص':'تلقائي';input.closest('.color-field').classList.toggle('custom',own);input.closest('.color-field').querySelector('button').disabled=!own;
  }
}
function effectiveSystems(){return Array.isArray(guide.size_systems)?guide.size_systems:(['women','general'].includes(guide.category)?UIX.SYSTEM_CODES.slice():[])}
function syncSystems(){
  const on=new Set(effectiveSystems());$('#sysChecks').replaceChildren(...UIX.SYSTEM_CODES.map(code=>{
    const l=document.createElement('label'),c=document.createElement('input');c.type='checkbox';c.checked=on.has(code);c.dataset.sys=code;
    c.onchange=()=>{const now=new Set(effectiveSystems());c.checked?now.add(code):now.delete(code);guide.size_systems=UIX.SYSTEM_CODES.filter(x=>now.has(x));$('#sysAuto').disabled=false;changed()};
    l.append(c,document.createTextNode(' '+code));return l}));
  $('#sysAuto').disabled=!Array.isArray(guide.size_systems);
}
$('#sysAuto').onclick=()=>{guide.size_systems=null;syncSystems();changed()};
function syncBody(){
  const b=guide.body_table;$('#bodyTitle').value=b?.title||'قياسات الجسم';$('#bodyPaste').value='';
  $('#bodyState').textContent=b?`الجدول الثاني مفعّل: ${b.rows.length} صفًا و${b.columns.length} أعمدة. للتعديل الصق جدولًا جديدًا ثم اضغط تطبيق.`:'لا يوجد جدول ثانٍ؛ يظهر جدول المنتج وحده.';
  $('#bodyRemove').disabled=!b;
}
function setBody(columns,rows){guide.body_table={title:($('#bodyTitle').value.trim()||'قياسات الجسم').slice(0,30),columns,rows};syncBody();changed()}
$('#bodyApply').onclick=()=>{
  try{const g=Import.toGrid($('#bodyPaste').value);setBody(g.columns,g.rows);toast('طُبّق جدول قياسات الجسم. راجع الأرقام وأكمل الخانات الفارغة.')}
  catch(e){toast(e.message||'تعذّرت قراءة الجدول.')}
};
$('#bodyStarter').onclick=()=>{
  const names=['الطول','الصدر','الخصر','الورك'],rows=guide.rows.map(r=>({size:r.size,values:names.map(()=>'')}));
  setBody(names.map(label=>({label,kind:'measurement'})),rows);toast('أُنشئ قالب بمقاساتك؛ اكتب نطاقات الجسم مباشرة بعد لصقها أو أعد اللصق.');
};
$('#bodyRemove').onclick=async()=>{if(!guide.body_table||!(await confirmAction('إزالة جدول قياسات الجسم من المسودة؟')))return;guide.body_table=null;syncBody();changed()};
$('#bodyTitle').oninput=()=>{if(guide.body_table){guide.body_table.title=($('#bodyTitle').value.trim()||'قياسات الجسم').slice(0,30);changed()}};
function syncAdvanced(){
  syncBody();syncSystems();
  $('#compareSizes').checked=guide.compare_sizes===true;
  $('#showFitDetails').checked=guide.show_fit_details===true;
  $('#fitDetailFields').hidden=!guide.show_fit_details;
  $('#fitAdvice').value=guide.fit_advice||'';
  $('#liningStretch').value=guide.lining_stretch||'';
  $('#reviewMeasurements').checked=guide.review_measurements===true;
  $('#guideFont').value=guide.font_family||'';$('#sizeLabel').value=guide.size_label||'';$('#stickySize').checked=guide.sticky_size!==false;$('#calculator').checked=guide.calculator===true;
  $('#howVideo').value=guide.how_video||'';$('#logoUrl').value=guide.logo_url||'';$('#howImages').value=(guide.how_images||[]).filter(x=>!isUpload(x)).join('\n');drawUploads();drawSide();syncColors();
}
function blankGrid(){return guide.rows.every(r=>r.values.every(v=>!String(v).trim()))}
function setCategory(id){
  if(!guide||guide.category===id)return;const blank=blankGrid(),base=Catalog?.defaults[id],fits=UIX?.themes.find(t=>t.id===guide.theme)?.cats.includes(id);
  guide.category=id;
  if(blank){const t=fresh(undefined,id);guide.columns=t.columns;guide.rows=t.rows}
  if(base&&(blank||!fits)){guide.theme=base.theme;guide.color=base.color;$('#guideColor').value=base.color}
  fillTemplates();renderThemes();syncChoices();drawGrid();changed();
  if(!blank)toast('تغيّرت الفئة والثيم فقط. اختر هيكلًا من القائمة ثم «استخدام الهيكل» إن أردت أعمدة جديدة.');
}
function drawGrid(){drawWidths();let html='<table><thead><tr><th>المقاس</th>'+guide.columns.map((c,i)=>`<th><input aria-label="اسم العمود ${i+1}" data-col="${i}" maxlength="40" value="${esc(c.label)}"><select aria-label="نوع العمود ${i+1}" data-kind="${i}"><option value="measurement" ${c.kind==='measurement'?'selected':''}>قياس: يتحول سم/إنش</option><option value="text" ${c.kind==='text'?'selected':''}>نص: EU / UK / غيره</option></select><button type="button" class="remove fill" data-fill="${i}" aria-label="إكمال العمود ${i+1} بنفس الفرق">أكمل العمود ⇣</button><button type="button" class="remove" data-remove-col="${i}" aria-label="حذف العمود ${i+1}">حذف العمود ×</button></th>`).join('')+'<th></th></tr></thead><tbody>'+guide.rows.map((r,i)=>`<tr><td><input aria-label="اسم المقاس ${i+1}" maxlength="30" data-size="${i}" value="${esc(r.size)}"></td>`+r.values.map((v,j)=>`<td><input aria-label="${esc(r.size)} ${esc(guide.columns[j].label)}" maxlength="60" data-row="${i}" data-cell="${j}" value="${esc(v)}" placeholder="—"></td>`).join('')+`<td><button type="button" class="remove" data-remove-row="${i}" aria-label="حذف المقاس ${esc(r.size)}">×</button></td></tr>`).join('')+'</tbody></table>';$('#gridEditor').innerHTML=html;
$('#gridEditor').querySelectorAll('[data-col]').forEach(x=>x.oninput=()=>{guide.columns[+x.dataset.col].label=x.value;changed()});$('#gridEditor').querySelectorAll('[data-kind]').forEach(x=>x.onchange=()=>{guide.columns[+x.dataset.kind].kind=x.value;changed()});$('#gridEditor').querySelectorAll('[data-size]').forEach(x=>x.oninput=()=>{guide.rows[+x.dataset.size].size=x.value;changed()});$('#gridEditor').querySelectorAll('[data-cell]').forEach(x=>x.oninput=()=>{guide.rows[+x.dataset.row].values[+x.dataset.cell]=x.value;changed()});$('#gridEditor').querySelectorAll('[data-fill]').forEach(x=>x.onclick=()=>fillColumn(+x.dataset.fill));$('#gridEditor').querySelectorAll('[data-remove-col]').forEach(x=>x.onclick=async()=>{if(guide.columns.length<=1)return toast('يجب إبقاء عمود قياس واحد على الأقل.');if(!(await confirmAction('حذف هذا العمود وقيمه من المسودة؟')))return;const i=+x.dataset.removeCol;guide.columns.splice(i,1);guide.rows.forEach(r=>r.values.splice(i,1));adjustPaint('col',i);drawGrid();changed()});$('#gridEditor').querySelectorAll('[data-remove-row]').forEach(x=>x.onclick=async()=>{if(guide.rows.length<=1)return toast('يجب إبقاء مقاس واحد على الأقل.');if(!(await confirmAction('حذف صف المقاس من المسودة؟')))return;guide.rows.splice(+x.dataset.removeRow,1);adjustPaint('row',+x.dataset.removeRow);drawGrid();changed()})}
function measurementWarnings() {
  const warnings=[];
  const sizes=['XXXS','XXS','XS','S','M','L','XL','XXL','XXXL'];
  function scan(chart, label, garment) {
    const missing=[],decreases=[];
    chart.columns.forEach((column,index)=>{
      if(column.kind!=='measurement')return;
      let previous=null;
      for(const row of chart.rows){
        const range=UIX.cellRange(row.values[index]);
        if(!range){
          missing.push((row.size||'صف بلا مقاس')+' / '+column.label);
          previous=null;
          continue;
        }
        const rank=sizes.indexOf(row.size.trim().toUpperCase());
        if(previous && rank>=0 && previous.rank>=0 && rank>previous.rank && range[0]<previous.low)
          decreases.push(column.label+' ('+previous.size+' ← '+row.size+')');
        previous={rank,low:range[0],size:row.size};
      }
    });
    const examples=items=>items.slice(0,3).join('، ')+(items.length>3?' وغيرها':'');
    if(missing.length)warnings.push(label+' — تحققي من الخانات التي لا تحتوي قياسًا رقميًا: '+examples(missing)+'.');
    if(decreases.length)warnings.push(label+' — راجعي تناقص القياس عند الانتقال إلى مقاس أكبر: '+examples(decreases)+'.');
    if(garment && !chart.instructions?.trim() && chart.columns.some(c=>c.kind==='measurement' && /^(الصدر|الخصر|الأرداف|chest|waist|hips?)$/i.test(c.label.trim())))
      warnings.push('وضّحي في اسم العمود أو إرشادات القياس هل الرقم عرض القطعة مفرودة أم محيطها الكامل.');
  }
  scan(guide,'الجدول الأساسي',guide.measurement_type==='garment');
  if(guide.body_table)scan(guide.body_table,'جدول الجسم',false);
  return warnings;
}
function drawMeasurementReview() {
  const box=$('#measurementReview');
  box.hidden=!guide.review_measurements;
  if(box.hidden)return;
  const items=measurementWarnings();
  $('#measurementIssues').replaceChildren(...(items.length?items:['لم يرصد الفحص ملاحظات على الخانات وتدرّج المقاسات.']).map(text=>mk('li','',text)));
}
async function save(action){
  if(!editing||saving||linkedTo)return;
  if(mode==='library'&&!libraryName.trim())return toast('اكتب اسمًا للجدول المشترك.');
  if(action==='publish'){
    const message=mode==='library'?`نشر هذا الجدول ليتحدث لدى ${libraryProducts.length} منتج مرتبط؟`:'نشر هذا الجدول ليظهر لعملاء المنتج المحدد؟';
    const warnings=guide.review_measurements?measurementWarnings():[];
    const prompt=warnings.length?'ملاحظات الفحص\n'+warnings.join('\n')+'\n\n'+message:message;
    if(!(await confirmAction(prompt)))return;
  }
  saving=true;const savedSnapshot=JSON.stringify(guide);$('#saveDraft').disabled=true;$('#publish').disabled=true;
  try{
    let d;
    if(mode==='library'){
      const body=JSON.stringify({version,name:libraryName.trim(),guide,action});
      d=libraryId?await api('size-library/'+libraryId+qs(),{method:'PUT',body}):await api('size-library'+qs(),{method:'POST',body});
      if(!libraryId)libraryId=d.library_id;
      canRestore=!!d.can_restore;
    }else d=await api('size-guides/'+encodeURIComponent(editing.product_id)+qs(),{method:'PUT',body:JSON.stringify({version,guide,action})});
    if(action==='publish')lastSeen=null;
    version=d.version;published=d.is_published;showPublication();dirty=JSON.stringify(guide)!==savedSnapshot;
    guideIndex=await api('size-guides'+qs());loadLibraryIndex().catch(()=>{});
    if(!dirty)fill();else{$('#editState').textContent='حُفظت النسخة السابقة؛ لديك تعديلات أحدث غير محفوظة.';$('#unpublish').disabled=!published}
    toast(action==='publish'?(mode==='library'?'نُشر الجدول المشترك لكل المنتجات المرتبطة.':'نُشر الجدول. سيظهر الزر بعد تركيب المقطع في سلة.'):'حُفظت المسودة دون تغيير النسخة المنشورة.');
  }catch(e){toast(e.message)}finally{saving=false;$('#saveDraft').disabled=false;$('#publish').disabled=false}
}

/* ---------- editor controls ---------- */
for(const [id,key] of [['guideTitle','title'],['buttonLabel','button_label'],['measureType','measurement_type'],['guideColor','color'],['instructions','instructions'],['notes','notes'],['fitAdvice','fit_advice'],['sizeLabel','size_label']])$('#'+id).oninput=()=>{if(!guide)return;guide[key]=$('#'+id).value;changed()};
for(const [id,key] of [['howVideo','how_video'],['logoUrl','logo_url']])$('#'+id).oninput=()=>{if(!guide)return;guide[key]=$('#'+id).value.trim();changed()};
const isUpload=value=>/^data:image\//.test(value);
function setHowImages(links,uploads){guide.how_images=[...links,...uploads].slice(0,4)}
function drawUploads(){
  const box=$('#howUploads');box.replaceChildren();if(!guide)return;
  (guide.how_images||[]).forEach((value,index)=>{if(!isUpload(value))return;
    const item=mk('div','upload-thumb'),img=mk('img'),remove=mk('button','secondary small','×');img.src=value;img.alt='صورة مرفوعة '+(index+1);remove.type='button';remove.setAttribute('aria-label','حذف الصورة');
    remove.onclick=()=>{guide.how_images=guide.how_images.filter((_,i)=>i!==index);drawUploads();changed()};item.append(img,remove);box.append(item)});
}
$('#howImages').oninput=()=>{if(!guide)return;const links=$('#howImages').value.split(/\n+/).map(x=>x.trim()).filter(Boolean),uploads=(guide.how_images||[]).filter(isUpload);setHowImages(links,uploads);changed()};
let sideSlot='';
function drawSide(){document.querySelectorAll('#sideRow .side-slot').forEach(slot=>{const key=slot.dataset.slot,box=slot.querySelector('[data-thumb]');box.replaceChildren();const value=guide?.[key];if(!value)return;
  const item=mk('div','upload-thumb'),img=mk('img'),remove=mk('button','secondary small','×');img.src=value;img.alt='صورة المنتج';remove.type='button';remove.setAttribute('aria-label','حذف الصورة');remove.onclick=()=>{guide[key]='';drawSide();changed()};item.append(img,remove);box.append(item)})}
document.querySelectorAll('#sideRow [data-up]').forEach(b=>b.onclick=()=>{sideSlot=b.closest('.side-slot').dataset.slot;$('#sideFile').click()});
$('#sideFile').onchange=async()=>{const file=$('#sideFile').files[0];$('#sideFile').value='';if(!file||!guide||!sideSlot)return;
  try{let data=await Import.imageToDataUrl(file,900,.8);if(data.length>280000)data=await Import.imageToDataUrl(file,640,.7);if(data.length>290000)return toast('الصورة كبيرة جدًا حتى بعد التصغير.');
    guide[sideSlot]=data;drawSide();changed();toast('تمت إضافة الصورة. اضغط حفظ لتظهر للعملاء.')}catch(error){toast(error.message||'تعذر رفع الصورة.')}};
$('#side3d').onchange=()=>{if(!guide)return;guide.side_3d=$('#side3d').checked;changed()};
$('#howUploadBtn').onclick=()=>$('#howUploadFile').click();
$('#howUploadFile').onchange=async()=>{
  const file=$('#howUploadFile').files[0];$('#howUploadFile').value='';if(!file||!guide)return;
  if((guide.how_images||[]).length>=4)return toast('الحد الأقصى 4 صور. احذف صورة أولًا.');
  try{
    let data=await Import.imageToDataUrl(file,900,.8);if(data.length>280000)data=await Import.imageToDataUrl(file,640,.7);
    if(data.length>290000)return toast('الصورة كبيرة جدًا حتى بعد التصغير. استخدم صورة أبسط أو رابطًا.');
    const links=(guide.how_images||[]).filter(x=>!isUpload(x)),uploads=(guide.how_images||[]).filter(isUpload);
    if(links.length+uploads.length>=4)return toast('الحد الأقصى 4 صور. احذف صورة أولًا.');
    uploads.push(data);setHowImages(links,uploads);drawUploads();changed();toast('تمت إضافة الصورة. اضغط حفظ لتظهر للعملاء.');
  }catch(error){toast(error.message||'تعذر رفع الصورة.')}
};
for(const [id,key] of [['depth3d','depth3d'],['headerIcon','header_icon'],['stickySize','sticky_size'],['calculator','calculator'],['compareSizes','compare_sizes'],['reviewMeasurements','review_measurements']])$('#'+id).onchange=()=>{if(guide){guide[key]=$('#'+id).checked;changed()}};
$('#resetTableColors').onclick=()=>{if(!guide)return;for(const [key] of COLOR_FIELDS)guide[key]='';changed()};
$('#guideUnit').onchange=async()=>{const to=$('#guideUnit').value;if(!(await confirmAction('سيتم تحويل القيم الرقمية والنطاقات إلى الوحدة الجديدة. هل تتابع؟'))){$('#guideUnit').value=guide.unit;return}guide.rows.forEach(r=>r.values=r.values.map((v,i)=>guide.columns[i].kind==='measurement'?window.SizeGuideUI.convert(v,guide.unit,to):v));if(guide.body_table)guide.body_table.rows.forEach(r=>r.values=r.values.map((v,i)=>guide.body_table.columns[i]?.kind==='measurement'?window.SizeGuideUI.convert(v,guide.unit,to):v));guide.unit=to;drawGrid();changed()};
$('#fillArtTips').onclick=async()=>{if(!guide)return;const art=guide.how_art==='none'?'auto':(guide.how_art||'auto'),{tips}=UIX.tipsFor(art,guide.category,guide.language==='en'?'en':'ar');if(!tips.length)return;if($('#instructions').value.trim()&&!(await confirmAction('استبدال نص الإرشادات الحالي بالنص الجاهز للرسم؟')))return;const text=tips.map((t,i)=>(i+1)+'. '+t).join('\n');guide.instructions=text;$('#instructions').value=text;changed()};
$('#suggestTips').onclick=async()=>{const t=Catalog?.find($('#template').value);if(!t?.tips)return toast('لا يوجد نص مقترح لهذا الهيكل.');if($('#instructions').value.trim()&&!(await confirmAction('استبدال نص الإرشادات الحالي بالنص المقترح؟')))return;guide.instructions=t.tips;$('#instructions').value=t.tips;changed()};
buildChoices();
$('#showFitDetails').onchange=()=>{
  if(!guide)return;
  guide.show_fit_details=$('#showFitDetails').checked;
  $('#fitDetailFields').hidden=!guide.show_fit_details;
  changed();
};
$('#liningStretch').onchange=()=>{if(guide){guide.lining_stretch=$('#liningStretch').value;changed()}};
$('#addColumn').onclick=()=>{if(guide.columns.length>=10)return toast('الحد الأقصى 10 أعمدة.');guide.columns.push({label:'قياس '+(guide.columns.length+1),kind:'measurement'});guide.rows.forEach(r=>r.values.push(''));drawGrid();changed()};$('#addRow').onclick=()=>{if(guide.rows.length>=30)return toast('الحد الأقصى 30 مقاسًا.');guide.rows.push({size:'',values:guide.columns.map(()=> '')});drawGrid();changed()};$('#applyTemplate').onclick=async()=>{if(!(await confirmAction('استبدال صفوف وأعمدة المسودة بهيكل فارغ؟')))return;const t=fresh($('#template').value,guide.category);guide.columns=t.columns;guide.rows=t.rows;if(t.category!==guide.category){guide.category=t.category;syncChoices()}drawGrid();changed()};$('#copyGuide').onclick=async()=>{const id=$('#copyFrom').value;if(!id)return toast('اختر المنتج المصدر.');if(!(await confirmAction('استبدال محتوى المسودة بجدول المنتج الآخر؟')))return;try{const d=await api('size-guides/'+encodeURIComponent(id)+qs());if(!d.guide)return toast('لا يوجد جدول لهذا المنتج.');guide=withDefaults(JSON.parse(JSON.stringify(d.guide)));fill();changed()}catch(e){toast(e.message)}};$('#previewModal').onclick=()=>window.SizeGuideUI.open(guide,editing.title);$('#saveDraft').onclick=()=>save('draft');$('#publish').onclick=()=>save('publish');
$('#unpublish').onclick=async()=>{
  if(!published||saving||!(await confirmAction(mode==='library'?'إخفاء الجدول المشترك عن عملاء كل المنتجات المرتبطة مع الاحتفاظ بالمسودة؟':'إخفاء دليل المقاسات عن عملاء هذا المنتج مع الاحتفاظ بالمسودة؟')))return;
  try{const path=mode==='library'?'size-library/'+libraryId+'/unpublish':'size-guides/'+encodeURIComponent(editing.product_id)+'/unpublish';const d=await api(path+qs(),{method:'POST',body:JSON.stringify({version})});version=d.version;published=false;if(mode==='library')canRestore=true;showPublication();$('#unpublish').disabled=true;$('#editState').textContent=dirty?'أُوقف الظهور؛ لديك تعديلات غير محفوظة.':'أُوقف الظهور. المسودة محفوظة.';guideIndex=await api('size-guides'+qs());toast('أُوقف نشر الجدول.')}catch(e){toast(e.message)}
};

/* ---------- import: pasted Excel/CSV or a photo read by Gemini ---------- */
function hidePending(){pending=null;$('#importPreview').classList.add('hidden');$('#importExtras').hidden=true}
/* Everything the photo said besides the grid. Each item is optional; fields the guide already fills start unticked so nothing is replaced by surprise. */
const unitName={cm:'سنتيمتر',in:'إنش'},typeName={body:'قياسات الجسم',garment:'قياسات القطعة نفسها'},languageName={ar:'العربية',en:'English'};
const IMPORT_EXTRAS=[
  ['title','عنوان النافذة',()=>guide.title,v=>v,v=>{guide.title=v;$('#guideTitle').value=v}],
  ['size_label','عنوان عمود المقاس',()=>guide.size_label,v=>v,v=>{guide.size_label=v;$('#sizeLabel').value=v}],
  ['unit','وحدة القياس',()=>guide.unit,v=>unitName[v],v=>{guide.unit=v;$('#guideUnit').value=v}],
  ['measurement_type','نوع القياسات',()=>guide.measurement_type,v=>typeName[v],v=>{guide.measurement_type=v;$('#measureType').value=v}],
  ['category','الفئة',()=>guide.category,v=>UIX?.categories.find(c=>c.id===v)?.name,v=>{guide.category=v;fillTemplates();renderThemes();syncChoices()}],
  ['language','لغة النافذة',()=>guide.language,v=>languageName[v],v=>{guide.language=v;syncChoices()}],
  ['instructions','إرشادات طريقة القياس',()=>guide.instructions,v=>v,v=>{guide.instructions=v;$('#instructions').value=v}],
  ['notes','الملاحظات',()=>guide.notes,v=>v,v=>{guide.notes=v;$('#notes').value=v}],
  ['look_style','تصميم الجدول في الصورة (ألوان وشكل)',()=>'',v=>{const n=['color','header_bg','header_text','row_alt','border_color','text_color','paper_color','size_bg','size_text'].filter(k=>v[k]).length;return (n||v.table_style)?`${n} من الألوان${v.table_style?' + نمط الصفوف والزوايا':''}`:''},v=>applyStyle({...styleOf(guide),...v},'من الصورة')],
  ['look_frame','تخطيط الجدول (عرض الأعمدة ومكان الصورة)',()=>'',v=>[(v.col_widths||[]).length?'نِسَب عرض الأعمدة':'',v.image_side&&v.image_side!=='none'?'مكان لصورة المنتج':''].filter(Boolean).join(' + '),v=>applyFrame(v)],
];
const rtl=()=>guide.language!=='en';
function applyFrame(frame){
  guide.col_widths=(frame.col_widths||[]).length===guide.columns.length+1?[...frame.col_widths]:[];
  if(frame.image_side&&frame.image_side!=='none'){
    const left=frame.image_side==='left';guide.side_layout=left===rtl()?'end':'start';guide.side_3d=true;
    toast('تركتُ مكانًا للصورة بجانب الجدول. ارفع صورة فستانك أو قطعتك من «ميزات للعميل».');
  }
  syncChoices();drawWidths();changed();
}
function renderExtras(){
  const list=$('#importExtraList');list.replaceChildren();let count=0;
  for(const [key,label,current,show] of IMPORT_EXTRAS){
    const value=pending?.[key];if(!value)continue;const text=show(value);if(!text)continue;count++;
    const existing=current(),replaces=!!existing&&String(existing)!==String(value)&&!['unit','measurement_type','language','category'].includes(key)&&String(existing).trim()!==''&&!(key==='title'&&existing==='دليل المقاسات');
    const row=mk('label','check import-extra'),box=mk('input');box.type='checkbox';box.dataset.key=key;box.checked=!replaces;
    const body=mk('span','');body.append(mk('b','',label+': '),document.createTextNode(text.length>120?text.slice(0,120)+'…':text));if(replaces)body.append(mk('small','',' (سيستبدل المكتوب حاليًا)'));
    row.append(box,body);list.append(row);
  }
  $('#importExtras').hidden=count===0;
}
function showPending(extraWarnings=[]){
  const table=mk('table'),head=mk('tr');head.append(mk('th','','المقاس'));for(const c of pending.columns)head.append(mk('th','',c.label+(c.kind==='measurement'?' ⌀':'')));
  const thead=mk('thead');thead.append(head);table.append(thead);const body=mk('tbody');
  for(const r of pending.rows){const tr=mk('tr');tr.append(mk('td','',r.size||'—'));for(const v of r.values)tr.append(mk('td','',v||'—'));body.append(tr)}
  table.append(body);$('#importTable').replaceChildren(table);
  const warnings=[...(pending.warnings||[]),...extraWarnings];
  $('#importWarnings').replaceChildren(...warnings.map(w=>mk('li','',w)));renderExtras();$('#importPreview').classList.remove('hidden');
}
$('#applyPaste').onclick=()=>{try{pending=Import.toGrid($('#pasteTable').value, {requireAll: mode==='library'});showPending()}catch(e){hidePending();toast(e.message)}};
$('#importCancel').onclick=hidePending;
$('#importTranspose').onclick=()=>{
  if(!pending)return;
  try{const swapped=Import.transpose(pending);pending={...pending,...swapped,warnings:[...swapped.warnings]};showPending(['قُلبت الصفوف والأعمدة. اضغط «تبديل» مرة أخرى لإرجاعها.'])}catch(e){toast(e.message)}
};
$('#importApply').onclick=async()=>{
  if(!pending)return;if(!blankGrid()&&!(await confirmAction('استبدال أعمدة وصفوف الجدول الحالي بالجدول المستورد؟')))return;
  guide.columns=pending.columns;guide.rows=pending.rows;
  const ticked=new Set([...document.querySelectorAll('#importExtraList input:checked')].map(i=>i.dataset.key));let applied=0;
  for(const [key,,,,apply] of IMPORT_EXTRAS)if(ticked.has(key)&&pending[key]){apply(pending[key]);applied++}
  hidePending();drawGrid();changed();toast('طُبّق الجدول المستورد'+(applied?' مع '+applied+' من الحقول المقروءة':'')+'. راجع الأرقام والنصوص ثم احفظ.');
};

/* ---- column widths: relative shares of the table's width */
function drawWidths(){
  const box=$('#widthEditor');box.replaceChildren();if(!guide)return;
  let widths=guide.col_widths||[];if(widths.length&&widths.length!==guide.columns.length+1){guide.col_widths=widths=[]}
  box.classList.remove('hidden');
  if(!widths.length){const b=mk('button','secondary small','ضبط عرض الأعمدة (اختياري)');b.type='button';b.onclick=()=>{guide.col_widths=[16,...guide.columns.map(()=>Math.max(8,Math.round(84/Math.max(guide.columns.length,1))))];drawWidths();changed()};box.append(b);return}
  box.append(mk('span','opt-label','عرض كل عمود (نسبة من عرض الجدول)'));const row=mk('div','width-row');
  const names=[guide.size_label||'المقاس',...guide.columns.map(c=>c.label||'—')];
  widths.forEach((n,i)=>{const label=mk('label','',names[i]),input=mk('input');input.type='number';input.min=3;input.max=80;input.step=1;input.value=n;input.setAttribute('aria-label','عرض '+names[i]);
    input.oninput=()=>{const v=Math.round(Number(input.value));if(v>=3&&v<=80){guide.col_widths[i]=v;changed()}};label.append(input);row.append(label)});
  const reset=mk('button','secondary small','إعادة العرض إلى تلقائي');reset.type='button';reset.onclick=()=>{guide.col_widths=[];drawWidths();changed()};box.append(row,reset);
}
/* Rows and columns move: painted parts follow them, and fixed widths no longer line up. */
function adjustPaint(kind,index){
  if(kind==='col')guide.col_widths=[];
  guide.cell_styles=Catalog.shiftPaint(guide.cell_styles,kind,index);
}
/* ---- editing right inside the live preview: type in a cell, add or delete rows and columns ---- */
let inlineEdit=false;
const editApi={
  pendingFocus:null,
  takeFocus(){const key=this.pendingFocus;this.pendingFocus=null;return key},
  set({part,row,col},text){
    if(part==='head'){if(!text){toast('اسم العمود مطلوب.');return false}guide.columns[col].label=text}
    else if(part==='sizeLabel'){guide.size_label=text;$('#sizeLabel').value=text}
    else if(part==='size')guide.rows[row].size=text;
    else guide.rows[row].values[col]=text;
    touch();drawGrid();return true;
  },
  add(what){
    if(what==='row'){if(guide.rows.length>=30)return toast('الحد الأقصى 30 صفًا.');guide.rows.push({size:'',values:guide.columns.map(()=>'')});this.pendingFocus='size:'+(guide.rows.length-1)+':-1'}
    else{if(guide.columns.length>=10)return toast('الحد الأقصى 10 أعمدة.');guide.columns.push({label:'قياس '+(guide.columns.length+1),kind:'measurement'});guide.rows.forEach(r=>r.values.push(''));guide.col_widths=[];this.pendingFocus='head:-1:'+(guide.columns.length-1)}
    drawGrid();changed();
  },
  async remove(what,index){
    if(what==='row'){
      if(guide.rows.length<=1)return toast('يجب إبقاء مقاس واحد على الأقل.');
      if(guide.rows[index].values.some(v=>String(v).trim())&&!(await confirmAction('حذف هذا الصف وقيمه من المسودة؟')))return;
      guide.rows.splice(index,1);adjustPaint('row',index);
    }else{
      if(guide.columns.length<=1)return toast('يجب إبقاء عمود واحد على الأقل.');
      if(guide.rows.some(r=>String(r.values[index]||'').trim())&&!(await confirmAction('حذف هذا العمود وقيمه من المسودة؟')))return;
      guide.columns.splice(index,1);guide.rows.forEach(r=>r.values.splice(index,1));adjustPaint('col',index);
    }
    drawGrid();changed();
  },
};
function syncInlineEdit(){
  const cards=guide?.layout_type==='cards';$('#inlineEditHint').textContent=!inlineEdit?'':cards?'التحرير المباشر يعمل مع عرض الجدول، اختر نوع عرض غير البطاقات.':'انقر على أي خلية واكتب. Enter ينقلك للصف التالي وEsc يلغي. القيم بوحدة الجدول.';
}
$('#inlineEdit').onchange=()=>{
  inlineEdit=$('#inlineEdit').checked;
  if(inlineEdit&&paintOn){paintOn=false;picked=null;$('#paintMode').checked=false;syncPaint()}
  syncInlineEdit();preview();
};
/* ---- paint mode: click a part of the live table, then colour it on its own */
let paintOn=false,picked=null,paintScope='this';
const clean=entry=>!entry.bg&&!entry.fg&&!entry.bold&&!entry.align;
const partName=p=>p.part==='head'?(p.col===-2?'عنوان المقاس':'عنوان «'+(guide.columns[p.col]?.label||'')+'»'):p.part==='size'?'مقاس «'+(guide.rows[p.row]?.size||'')+'»':'خلية «'+(guide.columns[p.col]?.label||'')+'» في صف «'+(guide.rows[p.row]?.size||'')+'»';
function scopes(p){
  if(p.part==='head')return[['this',partName(p),{target:'head',row:-1,col:p.col}],['all','كل الترويسة',{target:'head',row:-1,col:-1}]];
  if(p.part==='size')return[['this','هذا المقاس',{target:'size',row:p.row,col:-1}],['col','كل المقاسات',{target:'size',row:-1,col:-1}],['row','الصف كله',{target:'row',row:p.row,col:-1}]];
  return[['this','هذه الخلية',{target:'cell',row:p.row,col:p.col}],['row','الصف كله',{target:'row',row:p.row,col:-1}],['col','العمود كله',{target:'col',row:-1,col:p.col}]];
}
const sameTarget=(a,b)=>a.target===b.target&&(a.row??-1)===b.row&&(a.col??-1)===b.col;
const currentTarget=()=>picked&&(scopes(picked).find(x=>x[0]===paintScope)||scopes(picked)[0])[2];
const entryOf=t=>t&&(guide.cell_styles||[]).find(x=>sameTarget(x,t));
function setPart(change){
  const t=currentTarget();if(!t||!guide)return;const list=guide.cell_styles=guide.cell_styles||[];let entry=entryOf(t);
  if(!entry){entry={...t,bg:'',fg:'',bold:false,align:''};list.push(entry)}
  Object.assign(entry,change);if(clean(entry))guide.cell_styles=list.filter(x=>x!==entry);
  if(guide.cell_styles.length>150){guide.cell_styles=guide.cell_styles.slice(0,150);toast('وصلت للحد الأقصى من الأجزاء الملوّنة (150).')}
  changed();syncPaint();
}
function pickPart(p){picked=p;if(!scopes(p).some(x=>x[0]===paintScope))paintScope='this';syncPaint();preview()}
function syncPaint(){
  const panel=$('#paintPanel');panel.classList.toggle('hidden',!paintOn);if(!paintOn||!guide)return;
  $('#paintTarget').textContent=picked?'المحدد: '+partName(picked):'انقر على جزء من الجدول في المعاينة.';
  const seg=$('#paintScope');seg.replaceChildren();seg.classList.toggle('hidden',!picked);
  for(const [id,label] of (picked?scopes(picked):[])){const l=mk('label'),r=mk('input');r.type='radio';r.name='paint-scope';r.value=id;r.checked=id===paintScope;l.classList.toggle('selected',r.checked);l.append(r,mk('span','',label));seg.append(l);r.onchange=()=>{if(r.checked){paintScope=id;syncPaint()}}}
  const entry=entryOf(currentTarget())||{bg:'',fg:'',bold:false,align:''};
  for(const [key,id] of [['bg','paintBg'],['fg','paintFg']]){$('#'+id).value=entry[key]||(key==='bg'?'#ffffff':'#000000');$('#'+id+'State').textContent=entry[key]?entry[key]:'تلقائي';$('#'+id).disabled=!picked;$('#'+id+'Reset').disabled=!picked}
  $('#paintBold').checked=!!entry.bold;$('#paintAlign').value=entry.align||'';$('#paintBold').disabled=$('#paintAlign').disabled=!picked;
  $('#paintClearPart').disabled=!picked||!entryOf(currentTarget());$('#paintClearAll').disabled=!(guide.cell_styles||[]).length;
}
$('#paintMode').onchange=()=>{paintOn=$('#paintMode').checked;if(!paintOn)picked=null;if(paintOn&&inlineEdit){inlineEdit=false;$('#inlineEdit').checked=false;syncInlineEdit()}syncPaint();preview()};
$('#paintBg').oninput=()=>setPart({bg:$('#paintBg').value});$('#paintFg').oninput=()=>setPart({fg:$('#paintFg').value});
$('#paintBgReset').onclick=()=>setPart({bg:''});$('#paintFgReset').onclick=()=>setPart({fg:''});
$('#paintBold').onchange=()=>setPart({bold:$('#paintBold').checked});$('#paintAlign').onchange=()=>setPart({align:$('#paintAlign').value});
$('#paintClearPart').onclick=()=>{const t=currentTarget();if(!t||!guide)return;guide.cell_styles=(guide.cell_styles||[]).filter(x=>!sameTarget(x,t));changed();syncPaint()};
$('#paintClearAll').onclick=async()=>{if(!guide||!(guide.cell_styles||[]).length)return;if(!(await confirmAction('مسح كل التلوين اليدوي من هذا الجدول؟')))return;guide.cell_styles=[];picked=null;changed();syncPaint()};

/* ---- take the look of a table from a picture */
$('#styleFromImage').onclick=()=>$('#styleFile').click();
$('#styleFile').onchange=async()=>{
  const file=$('#styleFile').files[0];$('#styleFile').value='';if(!file||!guide)return;const status=$('#styleStatus'),button=$('#styleFromImage');
  button.disabled=true;status.textContent='جارٍ قراءة التصميم… قد يستغرق ذلك نصف دقيقة.';
  try{
    const image=await Import.imageToDataUrl(file);const d=await api('size-guide-ai-style'+qs(),{method:'POST',body:JSON.stringify({image})});
    applyStyle({...styleOf(guide),...d.style},'من الصورة');status.textContent='طُبّق تصميم الصورة. يمكنك التراجع بزر «تراجع».';loadBilling();
  }catch(e){status.textContent='';toast(e.message)}finally{button.disabled=false}
};
/* Plan banner: only shown once the server enforces plans (BILLING_ENFORCE). */
let billingState=null;
async function loadBilling(){
  const bar=$('#billingBar');
  try{const b=await api('billing'+qs());billingState=b&&b.enforced?b:null;if(!b||!b.enforced){bar.classList.add('hidden');renderPlan();return}
    const ai=b.ai,n=x=>Number(x).toLocaleString('ar');
    let text,tone='ok';
    if(b.plan==='unlimited')text='صلاحية كاملة غير محدودة لهذا المتجر: كل المزايا وصور الذكاء الاصطناعي بلا حد.';
    else if(b.plan==='trial')text=`تجربة مجانية: باقي ${n(b.trial_days_left)} يوم · صور الذكاء الاصطناعي المتبقية ${n(ai.remaining)} من ${n(ai.limit)}. للاشتراك (${n(b.price)} ر.س شهريًا) افتح صفحة التطبيق في سلة.`;
    else if(b.plan==='paid')text=`الاشتراك فعّال${b.paid_until?' حتى '+date(b.paid_until):''} · صور الذكاء الاصطناعي هذا الشهر: ${n(ai.plan_remaining)} من ${n(ai.limit)}${ai.extra?' + رصيد إضافي '+n(ai.extra):''}.`;
    else{text='انتهت التجربة أو الاشتراك: جداولك محفوظة لكنها مخفية عن عملائك حتى تشترك من صفحة التطبيق في سلة.';tone='warn'}
    bar.textContent=text;bar.dataset.tone=tone;bar.classList.remove('hidden');renderPlan();
  }catch{bar.classList.add('hidden')}
}
async function checkAi(){
  if(aiChecked)return;aiChecked=true;
  try{const d=await api('size-guide-ai-status'+qs());if(!d.available){$('#aiRun').disabled=true;$('#aiClone').disabled=true;$('#aiHint').textContent='القراءة بالذكاء الاصطناعي غير مفعّلة بعد: أضف المفتاح GEMINI_API_KEY في إعدادات الخادم (Render) ثم أعد تشغيل الخدمة.'}else if(typeof d.remaining==='number')$('#aiHint').textContent='المتبقي لك: '+d.remaining.toLocaleString('ar')+' صورة.';else if(d.plan==='unlimited')$('#aiHint').textContent='صور الذكاء الاصطناعي غير محدودة لمتجرك.'}catch{aiChecked=false}
}
new MutationObserver(()=>{if($('#importPanel').classList.contains('open'))checkAi()}).observe($('#importPanel'),{attributes:true,attributeFilter:['class']});
$('#aiFile').onchange=()=>{aiBlob=null};
$('#importPanel').addEventListener('paste',event=>{const item=[...(event.clipboardData?.items||[])].find(i=>i.type.startsWith('image/'));if(!item)return;event.preventDefault();aiBlob=item.getAsFile();$('#aiStatus').textContent='تم لصق صورة. اضغط «قراءة الجدول من الصورة».'});
$('#aiClone').onclick=async()=>{
  const file=aiBlob||$('#aiFile').files[0];if(!file)return toast('اختر صورة أو الصقها أولًا.');
  $('#aiClone').disabled=$('#aiRun').disabled=true;$('#aiStatus').textContent='جارٍ قراءة الجدول وتصميمه وتخطيطه… قد يستغرق ذلك نصف دقيقة.';
  try{
    const image=await Import.imageToDataUrl(file);const d=await api('size-guide-ai-clone'+qs(),{method:'POST',body:JSON.stringify({image})});
    const frame=d.frame&&((d.frame.col_widths||[]).length||d.frame.image_side!=='none')?d.frame:null;
    pending={...d,look_style:d.style&&Object.keys(d.style).length?d.style:null,look_frame:frame};delete pending.style;delete pending.frame;
    showPending(['قُرئ الجدول وتصميمه وتخطيطه بالذكاء الاصطناعي وقد يخطئ في بعض الأرقام والألوان؛ راجع كل شيء قبل النشر. يمكنك إلغاء أي جزء لا تريده من القائمة أعلاه.']);loadBilling();
    $('#aiStatus').textContent='تمت القراءة. راجع المعاينة وما قُرئ معها ثم اضغط «تطبيق على الجدول».';
  }catch(e){hidePending();$('#aiStatus').textContent='';toast(e.message)}finally{$('#aiRun').disabled=$('#aiClone').disabled=false}
};
$('#aiRun').onclick=async()=>{
  const file=aiBlob||$('#aiFile').files[0];if(!file)return toast('اختر صورة أو الصقها أولًا.');
  $('#aiRun').disabled=true;$('#aiStatus').textContent='جارٍ قراءة الجدول… قد يستغرق ذلك نصف دقيقة.';
  try{
    const image=await Import.imageToDataUrl(file);
    pending=await api('size-guide-ai-import'+qs(),{method:'POST',body:JSON.stringify({image})});
    showPending(['قُرئ الجدول بالذكاء الاصطناعي وقد يخطئ في بعض الأرقام؛ راجع كل خانة قبل النشر.']);loadBilling();$('#aiStatus').textContent='تمت القراءة. راجع المعاينة وما قُرئ معها ثم اضغط «تطبيق على الجدول».';
  }catch(e){hidePending();$('#aiStatus').textContent='';toast(e.message)}finally{$('#aiRun').disabled=false}
};

/* ---------- navigation and session ---------- */
$('#openButtonDesigns').onclick=()=>document.querySelector('[data-tab="buttonSettings"]').click();
$('#backCatalog').onclick=async()=>{if(!(await mayLeave()))return;dirty=false;const back=mode==='library'?'library':'catalog';show(back);if(back==='catalog')loadProducts().catch(e=>toast(e.message))};document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=async()=>{if(!(await mayLeave()))return;dirty=false;show(b.dataset.tab);if(b.dataset.tab==='catalog')loadProducts().catch(e=>toast(e.message))});window.addEventListener('beforeunload',e=>{if(dirty||window.SizeGuideBatch?.pending()||window.SizeGuideSettings?.isDirty()||window.SizeGuideSettings?.isBusy()){e.preventDefault();e.returnValue=''}});
$('#getSnippet').onclick=async()=>{try{let d=await api('size-guide-snippet'+qs()+'&generic=true');$('#snippet').value=d.javascript}catch(e){toast(e.message)}};$('#copySnippet').onclick=async()=>{if(!$('#snippet').value)return toast('ولّد الكود أولًا.');try{await navigator.clipboard.writeText($('#snippet').value);toast('تم نسخ الكود.')}catch{$('#snippet').select();toast('حدد الكود وانسخه يدويًا.')}};
$('#loginForm').onsubmit=async e=>{e.preventDefault();$('#loginButton').disabled=true;$('#error').textContent='';try{await api('login',{method:'POST',body:JSON.stringify({password:$('#password').value})});$('#password').value='';await boot()}catch(e){$('#error').textContent=e.message}finally{$('#loginButton').disabled=false}};$('#logout').onclick=async()=>{if(!(await mayLeave())||window.SizeGuideBatch && !(await window.SizeGuideBatch.leaveStore()))return;await api('logout',{method:'POST'});dirty=false;location.reload()};
$('#store').onchange=async()=>{if(!(await mayLeave())||window.SizeGuideBatch && !(await window.SizeGuideBatch.leaveStore())){$('#store').value=merchant;return}dirty=false;clearInterval(poll);poll=null;clearWorkbook();merchant=$('#store').value;page=1;selected.clear();libraries=[];savedStyles=[];savedPhrases=[];aiChecked=false;window.SizeGuideQuick?.clear();$('#snippet').value='';show('catalog');load().catch(e=>toast(e.message))};
$('#sync').onclick=async()=>{$('#sync').disabled=true;try{await api('sync'+qs(),{method:'POST'});await loadJobs();toast('بدأت مزامنة المنتجات.')}catch(e){toast(e.message);$('#sync').disabled=false}};$('#filter').oninput=()=>{clearTimeout(timer);timer=setTimeout(()=>{page=1;loadProducts().catch(e=>toast(e.message))},300)};$('#status').onchange=$('#guideFilter').onchange=()=>{page=1;loadProducts().catch(e=>toast(e.message))};$('#prev').onclick=()=>{page--;loadProducts().catch(e=>toast(e.message))};$('#next').onclick=()=>{page++;loadProducts().catch(e=>toast(e.message))};$('#refreshJobs').onclick=()=>loadJobs().catch(e=>toast(e.message));if(window.SizeGuideEmbedded){window.SizeGuideEmbedded.start(boot)}else{boot().catch(e=>{if(!e.message.includes('تسجيل الدخول'))$('#error').textContent=e.message})}
/* The editor's numbered sections become a folding menu: one open at a time, "open all" for the rest. */
(function foldSections(){
  const cards=[...document.querySelectorAll('#editFields > .ed-card')].filter(c=>c.querySelector(':scope>h3'));
  const shortcuts=new Map();
  const setOpen=(card,on)=>{
    card.classList.toggle('open',on);
    card.querySelector('.acc-btn').setAttribute('aria-expanded',String(on));
    shortcuts.get(card)?.setAttribute('aria-expanded',String(on));
  };
  cards.forEach((card,i)=>{
    const h=card.querySelector(':scope>h3'),body=document.createElement('div'),btn=document.createElement('button');
    body.className='acc-body';body.id='acc-body-'+i;[...card.childNodes].filter(n=>n!==h).forEach(n=>body.append(n));
    btn.type='button';btn.className='acc-btn';btn.setAttribute('aria-controls',body.id);while(h.firstChild)btn.append(h.firstChild);h.append(btn);
    card.classList.add('acc');card.append(body);setOpen(card,false);
    h.addEventListener('click',e=>{if(e.target.closest('.acc-btn')===null&&e.target!==h)return;const on=!card.classList.contains('open');if(on&&!openAll)cards.forEach(c=>c!==card&&setOpen(c,false));setOpen(card,on)});
  });
  let openAll=false;const first=document.getElementById('dataCard');
  if(first){setOpen(first,true);const tools=document.createElement('div'),b=document.createElement('button');tools.className='acc-tools';b.type='button';b.className='secondary';b.id='accAll';b.textContent='فتح كل الأقسام';
    const jumps=mk('div','editor-jumps');
    jumps.setAttribute('role','group');jumps.setAttribute('aria-label','الانتقال إلى قسم في محرر الجدول');
    for(const [id,label] of [['dataCard','البيانات'],['customerCard','ميزات العميل'],['presetCard','المظهر'],['customCard','تخصيص متقدم']]){
      const card=document.getElementById(id),jump=mk('button','secondary',label);
      jump.type='button';jump.setAttribute('aria-controls',card.querySelector('.acc-body').id);
      jump.setAttribute('aria-expanded',String(card===first));shortcuts.set(card,jump);
      jump.onclick=()=>{
        window.openEditorSection(card);
        card.querySelector('.acc-btn').focus({preventScroll:true});
        card.scrollIntoView?.({block:'start'});
      };
      jumps.append(jump);
    }
    tools.append(jumps);
    b.onclick=()=>{openAll=!openAll;b.textContent=openAll?'طيّ الأقسام':'فتح كل الأقسام';cards.forEach(c=>setOpen(c,openAll||c===first))};tools.append(b);first.before(tools)}
  window.openEditorSection=card=>{if(card?.classList?.contains('acc')){if(!openAll)cards.forEach(c=>{if(c!==card)setOpen(c,false)});setOpen(card,true)}};
})();

/* Import a workbook as independent library drafts after reviewing its worksheets. */
let workbookReview=null;
const workbookFile=$('#workbookFile'),workbookSheets=$('#workbookSheets'),saveWorkbook=$('#saveWorkbook');
function clearWorkbook(){
  workbookReview=null;
  workbookFile.value='';
  workbookSheets.replaceChildren();
  $('#workbookReview').hidden=true;
}
$('#chooseWorkbook').onclick=()=>workbookFile.click();
$('#cancelWorkbook').onclick=clearWorkbook;
workbookFile.onchange=async()=>{
  const file=workbookFile.files[0];
  clearWorkbook();
  if(!file)return;
  if(!/\.xlsx$/i.test(file.name)||file.size>2_000_000)return toast('اختر ملف xlsx بحجم لا يتجاوز ٢ ميغابايت.');
  const review={store:merchant,id:crypto.randomUUID(),items:[]};
  workbookReview=review;
  try{
    const content=await new Promise((resolve,reject)=>{
      const reader=new FileReader();
      reader.onload=()=>resolve(reader.result.split(',')[1]);reader.onerror=()=>reject(Error('تعذرت قراءة الملف.'));
      reader.readAsDataURL(file);
    });
    const sheets=await api('size-workbook/preview?'+new URLSearchParams({merchant:review.store}),{method:'POST',body:JSON.stringify({content})});
    if(review!==workbookReview||merchant!==review.store)return;
    $('#workbookReview').hidden=false;
    for(const sheet of sheets){
      const block=mk('div','ed-card'),label=mk('label'),check=mk('input');
      check.type='checkbox';label.append(check,document.createTextNode(' '+sheet.name));block.append(label);workbookSheets.append(block);
      if(sheet.error){check.disabled=true;block.append(mk('p','micro',sheet.error));continue}
      const text=sheet.rows.map(row=>row.map(v=>'"'+v.replace(/"/g,'""')+'"').join('\t')).join('\n');
      const grid=Import.toGrid(text,{requireAll:true});
      const table=mk('table'),details=mk('details'),scroll=mk('div','tablewrap');
      details.append(mk('summary','',`معاينة ${grid.rows.length} مقاسًا`));
      for(const [i,row] of sheet.rows.entries()){
        const tr=table.insertRow();for(const value of row)tr.append(mk(i===0?'th':'td','',value));
      }
      scroll.append(table);details.append(scroll);block.append(details);
      check.checked=true;
      review.items.push({check,name:sheet.name,guide:{...fresh(),title:sheet.name,columns:grid.columns,rows:grid.rows,size_label:grid.sizeHeader}});
    }
    saveWorkbook.disabled=!review.items.length;
    if(!sheets.length)workbookSheets.append(mk('p','micro','لا توجد أوراق ظاهرة في الملف.'));
  }catch(e){if(review===workbookReview){clearWorkbook();toast(e.message)}}
};
saveWorkbook.onclick=async()=>{
  const review=workbookReview;
  if(!review||review.store!==merchant||saving)return;
  const sheets=review.items.filter(item=>item.check.checked).map(({name,guide})=>({name,guide}));
  if(!sheets.length)return toast('حدّد ورقة واحدة على الأقل.');
  saving=true;saveWorkbook.disabled=true;$('#chooseWorkbook').disabled=true;$('#cancelWorkbook').disabled=true;
  try{
    await api('size-workbook/save'+qs(),{method:'POST',body:JSON.stringify({request_id:review.id,sheets})});
    clearWorkbook();await loadLibrary();toast(`حُفظت ${sheets.length} من أوراق الملف في جداولي.`);
  }catch(e){toast(e.message)}finally{saving=false;saveWorkbook.disabled=false;$('#chooseWorkbook').disabled=false;$('#cancelWorkbook').disabled=false}
};
