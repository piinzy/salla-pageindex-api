// Guide editor, shared library, bulk actions, imports and statistics, driven through the real dashboard markup.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {JSDOM,VirtualConsole}=require('jsdom');
const file=name=>fs.readFileSync(path.join(__dirname,'static',name),'utf8');
const flush=()=>new Promise(resolve=>setImmediate(resolve));
async function settle(){for(let i=0;i<8;i++)await flush();}
const LIB='aaaaaaaaaaaa',NEWLIB='bbbbbbbbbbbb';
const oldGuide={title:'دليل قديم',button_label:'دليل',unit:'cm',measurement_type:'body',columns:[{label:'الصدر',kind:'measurement'}],rows:[{size:'M',values:['94']}],notes:'',instructions:'',color:'#123456'};

(async()=>{
  const errors=[],console_=new VirtualConsole();console_.on('jsdomError',e=>errors.push(e));
  const dom=new JSDOM(file('dashboard.html'),{url:'https://app.test/dashboard',runScripts:'dangerously',virtualConsole:console_}),w=dom.window,d=w.document;
  try{
    w.structuredClone=structuredClone;let confirmed=true;w.confirm=()=>confirmed;
    const calls=[];let aiAvailable=true;const rules={rules:[],categories:[{id:'100',name:'فساتين',products:3,without_guide:2}],missing:2,latest:[]};let billing={enforced:true,plan:'trial',trial_days_left:5,price:389,paid_until:null,ai:{limit:3,used:0,plan_remaining:3,extra:0,remaining:3}};const presets={styles:[{preset_id:'s00000000001',name:'تصميم قديم',style:{theme:'velvet',color:'#7b2338',table_style:'cards',density:'compact',corners:'round',depth3d:false,header_icon:true,size_style:'square',header_style:'solid',border_style:'none',font_scale:'small',sticky_size:true,header_bg:'',header_text:'',row_alt:'',border_color:'',text_color:'',paper_color:'',size_bg:'',size_text:''}}],phrases:[{preset_id:'f00000000001',name:'جملتي',text:'جملة محفوظة من التاجر'}],n:1};
    const call=(method,part)=>calls.filter(c=>c.method===method&&c.path.includes(part));
    const guideIndex=()=>[{product_id:'43',title:'منتج قديم',sku:'S2',version:3,is_published:true,has_changes:false,library_id:null},
      {product_id:'44',title:'منتج مرتبط',sku:'S3',version:1,is_published:true,has_changes:false,library_id:LIB,library_name:'فساتين'}];
    w.fetch=async(url,options={})=>{
      const u=new URL(url,'https://app.test'),p=u.pathname.replace('/dashboard-api/',''),method=options.method||'GET',body=options.body?JSON.parse(options.body):null;
      calls.push({method,path:p+u.search,body});let data=[];
      if(p==='stores')data=[{merchant_id:'123',store_name:'متجر',product_count:3,connected:true}];
      else if(p==='products')data={items:[{product_id:'42',title:'منتج جديد',sku:'S1',price:10,currency:'SAR',quantity:2,status:'sale'},{product_id:'43',title:'منتج قديم',sku:'S2',price:10,currency:'SAR',quantity:2,status:'sale'},{product_id:'44',title:'منتج مرتبط',sku:'S3',price:10,currency:'SAR',quantity:2,status:'sale'}],pages:1,total:3};
      else if(p==='button-settings')data={settings:{design:'outline'},version:0};
      else if(p==='size-guides')data=guideIndex();
      else if(p==='size-guides/42'&&method==='PUT')data={version:body.version+1,is_published:body.action==='publish'};
      else if(p==='size-guides/42')data={product:{product_id:'42',title:'منتج جديد',sku:'S1'},guide:null,version:0,is_published:false,library:null};
      else if(p==='size-guides/43')data={product:{product_id:'43',title:'منتج قديم',sku:'S2'},version:3,is_published:true,library:null,guide:oldGuide};
      else if(p==='size-guides/44')data={product:{product_id:'44',title:'منتج مرتبط',sku:'S3'},version:1,is_published:true,library:{library_id:LIB,name:'فساتين'},guide:{...oldGuide,title:'من المكتبة'}};
      else if(p==='size-guides/unlink')data={unlinked:body.product_ids,skipped:[]};
      else if(p==='size-guides/copy')data={copied:body.product_ids.filter(x=>x!==body.source_product_id),skipped:['43']};
      else if(p==='size-guides/bulk')data={updated:body.product_ids.slice(0,1),skipped:body.product_ids.slice(1).map(product_id=>({product_id,reason:'لا يوجد جدول'}))};
      else if(p==='size-library'&&method==='GET')data=[{library_id:LIB,name:'فساتين',version:2,is_published:true,has_changes:false,category:'women',theme:'rose',product_count:1}];
      else if(p==='size-library'&&method==='POST')data={library_id:NEWLIB,version:1,is_published:body.action==='publish'};
      else if(p===`size-library/${LIB}`&&method==='GET')data={library_id:LIB,name:'فساتين',guide:{...oldGuide,title:'جدول مشترك'},version:2,is_published:true,products:[{product_id:'44',title:'منتج مرتبط',sku:'S3'}]};
      else if(p===`size-library/${NEWLIB}`&&method==='GET')data={library_id:NEWLIB,name:'جديد',guide:oldGuide,version:1,is_published:false,products:[{product_id:'42',title:'منتج جديد',sku:'S1'}]};
      else if(p===`size-library/${NEWLIB}/link`)data={linked:body.product_ids,skipped:[]};
      else if(p.startsWith('size-library/')&&p.endsWith('/link'))data={linked:body.product_ids,skipped:['x']};
      else if(p===`size-library/${NEWLIB}`&&method==='PUT')data={library_id:NEWLIB,version:body.version+1,is_published:body.action==='publish'};
      else if(p===`size-library/${NEWLIB}`&&method==='DELETE')data={deleted:true};
      else if(p==='size-presets'&&method==='GET')data={styles:presets.styles,phrases:presets.phrases};
      else if(p==='size-presets'&&method==='POST'){const item={preset_id:'p'+(presets.n++).toString(16).padStart(11,'0'),name:body.name,...(body.kind==='style'?{style:body.style}:{text:body.text})};presets[body.kind==='style'?'styles':'phrases'].push(item);data=item}
      else if(p.startsWith('size-presets/')&&method==='DELETE'){const id=p.split('/')[1].split('?')[0];presets.styles=presets.styles.filter(x=>x.preset_id!==id);presets.phrases=presets.phrases.filter(x=>x.preset_id!==id);data={deleted:true}}
      else if(p==='size-rules'&&method==='GET')data=rules;
      else if(p==='size-rules'&&method==='PUT'){rules.rules=[{category_id:body.category_id,category_name:'فساتين',library_id:body.library_id,library_name:'فساتين',products:3}];data=rules}
      else if(p.startsWith('size-rules/')&&p!=='size-rules/apply'&&method==='DELETE'){rules.rules=[];data=rules}
      else if(p==='size-rules/apply'){rules.missing=0;data={linked:2,...rules}}
      else if(p==='size-insights')data={days:+u.searchParams.get('days'),since:'2026-10-01T00:00:00Z',sold:20,returned:5,rate:.25,alerts:[{kind:'size',product_id:'42',title:'فستان كريب',size:'M',sold:10,returned:4,rate:.4,message:'40% من مبيعات المقاس M رُجعت (4 من 10). راجع قياسات هذا المقاس في الجدول.'}],products:[{product_id:'42',title:'فستان كريب',sold:20,returned:5,rate:.25,sizes:[{size:'M',sold:10,returned:4,rate:.4},{size:'S',sold:10,returned:1,rate:.1}]}]};
      else if(p==='billing')data=billing;
      else if(p==='size-guide-ai-status')data={available:aiAvailable};
      else if(p==='size-guide-ai-clone')data={columns:[{label:'الصدر',kind:'measurement'},{label:'الخصر',kind:'measurement'}],rows:[{size:'S',values:['86','70']},{size:'M',values:['90','74']}],unit:'cm',warnings:[],style:{color:'#336699',header_bg:'#e8eef5',table_style:'lines'},frame:{col_widths:[20,40,40],image_side:'left',image_kind:'dress',image_views:2}};
      else if(p==='size-guide-ai-style')data={style:{color:'#336699',header_bg:'#e8eef5',header_text:'',row_alt:'',border_color:'#ccd6e0',text_color:'',paper_color:'#ffffff',size_bg:'',size_text:'',table_style:'lines',corners:'sharp'}};
      else if(p==='size-guide-ai-import')data={columns:[{label:'الصدر',kind:'measurement'},{label:'EU',kind:'text'}],rows:[{size:'S',values:['86','36']},{size:'M',values:['','38']}],unit:'in',notes:'ملاحظة من الصورة',warnings:['خانة فارغة'],title:'عنوان من الصورة',size_label:'المقاس',measurement_type:'garment',category:'pets',language:'ar',instructions:'تعليمات من الصورة'};
      else if(p==='size-guide-stats')data={days:+u.searchParams.get('days'),opens:12,calcs:3,published_guides:2,daily:[{day:new Date().toISOString().slice(0,10),opens:12,calcs:3}],top:[{product_id:'43',title:'منتج قديم',opens:12,calcs:3}]};
      return {ok:true,json:async()=>JSON.parse(JSON.stringify(data))};   // a real response is never the server's own object
    };
    for(const name of ['size-guide-renderer.js','size-guide-catalog.js','size-guide-import.js','size-guide-button.js','size-guide-placement.js','button-settings-admin.js','size-guide-admin.js']){
      const script=d.createElement('script');script.textContent=file(name);d.body.append(script);
    }
    await settle();assert.equal(errors.length,0,errors.map(e=>e.message).join('\n'));
    const $=s=>d.querySelector(s),all=s=>[...d.querySelectorAll(s)],input=(s,v)=>{$(s).value=v;$(s).dispatchEvent(new w.Event('input',{bubbles:true}));};
    const change=(s,checked)=>{$(s).checked=checked;$(s).dispatchEvent(new w.Event('change',{bubbles:true}));};
    const guideWrap=()=>$('#guidePreview').shadowRoot.querySelector('.wrap');
    const hidden=s=>$(s).classList.contains('hidden');
    assert.equal(all('#categoryChoices [name="guide-category"]').length,4);const pickCat=id=>{const sel=$('#specialType');sel.value=id;sel.dispatchEvent(new w.Event('change',{bubbles:true}))};

    // plan banner: trial days and AI allowance, hidden when plans are not enforced
    assert.equal(hidden('#billingBar'),false);assert.match($('#billingBar').textContent,/تجربة مجانية/);assert.match($('#billingBar').textContent,/389/);assert.equal($('#billingBar').dataset.tone,'ok');
    // products without a guide are offered up front
    assert.equal(hidden('#missingBar'),false);assert.match($('#missingBar').textContent,/2|٢/);assert.match($('#missingBar').textContent,/أنشئ قاعدة/);
    $('#guideFilter').value='none';$('#guideFilter').dispatchEvent(new w.Event('change'));await settle();assert.match(calls.filter(c=>c.path.startsWith('products?')).pop().path,/guide=none/);$('#guideFilter').value='';$('#guideFilter').dispatchEvent(new w.Event('change'));await settle();
    // ---- a brand-new guide starts as the plain standard table: general category, Salla-like reference theme, no drawing
    $('[data-edit="42"]').click();await settle();
    assert.equal(hidden('#editor'),false);assert.equal($('[name="guide-category"]:checked').value,'special');assert.equal($('[name="guide-theme"]:checked').value,'atlas');
    assert.equal(all('#themeChoices [name="guide-theme"]').length,20);assert.equal($('#themeChoices .theme-card [name="guide-theme"]').value,'atlas','gallery order');
    assert.ok($('#themeChoices .theme-card .preset-mini'));
    assert.equal(all('#template option').length,w.SizeGuideCatalog.templates.length,'every ready-made structure is offered, grouped by type');assert.equal($('#template').value,'general-basic');assert.ok(all('#template optgroup').length>=7);
    assert.equal(all('#gridEditor thead th input').length,3);assert.equal(guideWrap().dataset.theme,'atlas');assert.equal($('#guidePreview').shadowRoot.querySelector('svg.emblem'),null,'plain start has no drawing');
    assert.equal($('#calculator').checked,false,'plain start has no size finder');assert.equal(hidden('.only-library'),true);assert.equal(hidden('.only-product'),false);

    // ---- category follows an untouched guide
    pickCat('shoes');await settle();
    assert.deepEqual(all('#gridEditor thead th input').map(i=>i.value),['UK','US','طول القدم','عرض القدم']);
    assert.equal($('[name="guide-theme"]:checked').value,'continental');assert.equal($('#guideColor').value,'#272821');assert.equal(all('#gridEditor tbody tr').length,6);
    pickCat('accessories');await settle();
    assert.equal($('#template').value,'acc-rings');assert.equal($('[name="guide-theme"]:checked').value,'numeric');

    // ---- theme, colour and style options reach the preview
    pickCat('shoes');await settle();
    $('[name="guide-theme"][value="precision"]').click();await settle();
    assert.equal(guideWrap().dataset.theme,'precision');assert.equal($('#guideColor').value,'#39383b');
    input('#guideColor','#336699');assert.equal(guideWrap().style.getPropertyValue('--accent'),'#336699');
    $('[name="guide-table_style"][value="cards"]').click();$('[name="guide-density"][value="compact"]').click();$('[name="guide-corners"][value="round"]').click();
    assert.deepEqual([guideWrap().dataset.table,guideWrap().dataset.density,guideWrap().dataset.corners],['cards','compact','round']);
    change('#depth3d',false);assert.equal(guideWrap().dataset.depth,'0');change('#headerIcon',false);assert.equal($('#guidePreview').shadowRoot.querySelector('svg.emblem'),null);

    // ---- advanced table options: size cell, header, borders, font, sticky column, language, finder
    for(const [name,value] of [['size_style','underline'],['header_style','solid'],['border_style','strong'],['font_scale','large'],['language','en']])$(`[name="guide-${name}"][value="${value}"]`).click();
    input('#sizeLabel','الحجم');change('#stickySize',false);
    const wrap=guideWrap();assert.deepEqual([wrap.dataset.sizestyle,wrap.dataset.head,wrap.dataset.border,wrap.dataset.font,wrap.dataset.sticky],['underline','solid','strong','large','0']);
    assert.equal(wrap.dir,'ltr');
    $('[name="guide-language"][value="ar"]').click();assert.equal(guideWrap().dir,'rtl');assert.equal($('#guidePreview').shadowRoot.querySelector('thead th').textContent,'الحجم');
    // layout type and fit scale: menus with hints, and the live preview follows
    assert.equal(all('#layoutSeg input').length,4);assert.equal($('[name="guide-layout_type"]:checked').value,'compact');
    $('[name="guide-layout_type"][value="cards"]').click();assert.equal(guideWrap().dataset.layout,'cards');assert.ok($('#guidePreview').shadowRoot.querySelector('.size-card'));assert.match($('#layoutHint').textContent,/بطاقة لكل مقاس/);
    $('[name="guide-layout_type"][value="page"]').click();assert.equal($('#guidePreview').shadowRoot.querySelector('[role=tab]'),null);$('[name="guide-layout_type"][value="tabs"]').click();assert.ok($('#guidePreview').shadowRoot.querySelector('[role=tab]'));
    assert.equal(all('#fitSeg input').length,4);assert.equal($('#guidePreview').shadowRoot.querySelector('.fit'),null);$('[name="guide-fit_level"][value="regular"]').click();assert.equal($('#guidePreview').shadowRoot.querySelector('.fit').dataset.level,'regular');
    $('[name="guide-fit_level"][value=""]').click();assert.equal($('#guidePreview').shadowRoot.querySelector('.fit'),null);
    assert.match($('#importPanel').textContent,/تملك حقوقه/,'imports say which charts are fair to upload');
    change('#calculator',false);assert.equal($('#guidePreview').shadowRoot.querySelectorAll('[role=tab]').length,2);change('#calculator',true);assert.equal($('#guidePreview').shadowRoot.querySelectorAll('[role=tab]').length,3);
    // colours: automatic until the merchant picks one, and every colour can be reset
    // Applying a whole-chart palette leaves the structure untouched and can restore a previous custom color.
    {
      const buttons=all('#guidePalettes button');
      assert.equal(buttons.length,9);
      const original=guideWrap().dataset.theme,layout=guideWrap().dataset.layout;
      const before=all('#gridEditor tbody input').map(x=>x.value);
      input('#tc-paper_color','#f0ebeb');
      buttons[0].click();assert.equal(buttons[0].getAttribute('aria-pressed'),'true');
      assert.equal($('#tc-paper_color').value,'#fffaf1');assert.equal(guideWrap().dataset.theme,original);
      assert.equal(guideWrap().dataset.layout,layout);
      assert.deepEqual(all('#gridEditor tbody input').map(x=>x.value),before);
      $('#undoPalette').click();assert.equal($('#tc-paper_color').value,'#f0ebeb');
      const formal=$('#guidePalettes [data-palette="formal"]');
      formal.click();assert.equal(formal.getAttribute('aria-pressed'),'true');
      assert.equal($('#tc-paper_color').value,'#ffffff');assert.equal($('#tc-text_color').value,'#242424');
      input('#tc-row_alt','#404556');assert.equal(formal.getAttribute('aria-pressed'),'false');
      $('#resetTableColors').click();
    }
    assert.equal(all('#tableColors .color-field').length,8);assert.equal($('#tc-status-header_bg').textContent,'تلقائي');assert.equal($('#tc-header_bg').closest('.color-field').querySelector('button').disabled,true);
    const auto=$('#tc-row_alt').value;assert.match(auto,/^#[0-9a-f]{6}$/);
    input('#tc-header_bg','#101010');input('#tc-size_bg','#ffeeaa');
    assert.equal($('#tc-status-header_bg').textContent,'مخصص');assert.equal(guideWrap().style.getPropertyValue('--head-bg'),'#101010');assert.equal(guideWrap().style.getPropertyValue('--head-ink'),'#ffffff');assert.equal(guideWrap().style.getPropertyValue('--chip-bg'),'#ffeeaa');
    $('#tc-header_bg').closest('.color-field').querySelector('button').click();assert.equal($('#tc-status-header_bg').textContent,'تلقائي');assert.notEqual(guideWrap().style.getPropertyValue('--head-bg'),'#101010');
    input('#tc-text_color','#202020');$('#resetTableColors').click();assert.ok(all('#tableColors .color-field').every(f=>!f.classList.contains('custom')),'reset restores every colour');
    input('#tc-border_color','#ff0000');
    // media and logo
    input('#howVideo','https://youtu.be/dQw4w9WgXcQ');input('#logoUrl','https://cdn.example.com/logo.png');input('#howImages','https://cdn.example.com/a.jpg\n\n  https://cdn.example.com/b.jpg  \n1\n2\n3\n4');
    assert.ok($('#guidePreview').shadowRoot.querySelector('iframe'));assert.ok($('#guidePreview').shadowRoot.querySelector('img.logo'));

    // ---- once numbers are entered, the category keeps them
    input('#gridEditor [data-row="0"][data-cell="2"]','24.5');input('#guideTitle','دليل الأحذية');
    pickCat('pets');await settle();
    assert.equal($('#gridEditor [data-row="0"][data-cell="2"]').value,'24.5','entered data is never discarded');assert.equal($('[name="guide-theme"]:checked').value,'ranges');assert.ok(all('#template option').some(o=>o.value==='pets-dog'));
    $('#template').value='pets-dog';confirmed=false;$('#applyTemplate').click();await settle();assert.equal($('#gridEditor thead th input').value,'UK','declined replacement keeps the table');
    confirmed=true;$('#applyTemplate').click();await settle();
    assert.deepEqual(all('#gridEditor thead th input').map(i=>i.value),['محيط الرقبة','محيط الصدر','طول الظهر','الوزن (كجم)']);
    $('#suggestTips').click();await settle();assert.match($('#instructions').value,/الأرجل الأمامية/);

    // ---- import: pasted Excel text
    assert.equal(hidden('#importPreview'),true);
    input('#pasteTable','المقاس\tالصدر\tالخصر\tEU\nS\t90-94\t70\t36\nM\t96\t74\t38\nL\t\t78\t40');$('#applyPaste').click();
    assert.equal(hidden('#importPreview'),false);assert.equal(all('#importTable tbody tr').length,3);assert.ok(all('#importWarnings li').some(li=>/فارغة/.test(li.textContent)));
    input('#gridEditor [data-row="0"][data-cell="0"]','31');   // the table now holds numbers, so replacing it needs a yes
    confirmed=false;$('#importApply').click();await settle();assert.equal($('#gridEditor thead th input').value,'محيط الرقبة','declined import keeps the table');
    confirmed=true;$('#importApply').click();await settle();
    assert.deepEqual(all('#gridEditor thead th input').map(i=>i.value),['الصدر','الخصر','EU']);assert.equal(all('#gridEditor tbody tr').length,3);assert.equal(hidden('#importPreview'),true);
    input('#pasteTable','only one line');$('#applyPaste').click();assert.equal(hidden('#importPreview'),true,'an unusable paste shows a message and no preview');
    // a chart printed with the sizes across the top can be flipped before it is applied
    input('#pasteTable','المقاس\t38/S\t40/M\nمحيط الصدر\t91.4\t96.5\nالطول\t147.3\t147.3');$('#applyPaste').click();
    const heads=()=>all('#importTable thead th').map(th=>th.textContent.replace(/ ⌀$/,''));
    assert.deepEqual(heads(),['المقاس','38/S','40/M']);assert.deepEqual(all('#importTable tbody tr').map(tr=>tr.firstChild.textContent),['محيط الصدر','الطول']);
    $('#importTranspose').click();assert.deepEqual(heads(),['المقاس','محيط الصدر','الطول']);assert.deepEqual(all('#importTable tbody tr').map(tr=>tr.firstChild.textContent),['38/S','40/M']);
    assert.ok(all('#importWarnings li').some(li=>/قُلبت/.test(li.textContent)));
    $('#importTranspose').click();assert.deepEqual(heads(),['المقاس','38/S','40/M'],'a second press restores the first orientation');$('#importTranspose').click();
    confirmed=true;$('#importApply').click();await settle();
    assert.deepEqual(all('#gridEditor thead th input').map(i=>i.value),['محيط الصدر','الطول']);assert.deepEqual(all('#gridEditor tbody tr').map(tr=>tr.querySelector('[data-size]').value),['38/S','40/M']);
    assert.equal($('#gridEditor [data-row="1"][data-cell="0"]').value,'96.5');assert.equal(hidden('#importPreview'),true);
    $('#importTranspose').click();assert.equal(hidden('#importPreview'),true,'nothing happens without a proposal');
    // import: photo read by Gemini (the server is stubbed; the canvas step is replaced)
    w.SizeGuideImport.imageToDataUrl=async()=> 'data:image/jpeg;base64,/9j/AAAA';
    $('#importPanel .acc-btn').click();await settle();assert.ok($('#importPanel').classList.contains('open'),'import is its own folding section');assert.equal($('#aiRun').disabled,false);
    $('#aiRun').click();await settle();assert.equal(calls.filter(c=>c.path.startsWith('size-guide-ai-import')).length,0,'nothing is sent without an image');
    const paste=new w.Event('paste',{bubbles:true,cancelable:true});paste.clipboardData={items:[{type:'text/plain'},{type:'image/png',getAsFile:()=>new w.File(['x'],'chart.png',{type:'image/png'})}]};$('#importPanel').dispatchEvent(paste);assert.equal(paste.defaultPrevented,true);
    $('#aiRun').click();await settle();
    const ai=calls.find(c=>c.path.startsWith('size-guide-ai-import'));assert.equal(ai.method,'POST');assert.match(ai.body.image,/^data:image\/jpeg;base64,/);assert.deepEqual(Object.keys(ai.body),['image']);
    assert.equal(hidden('#importPreview'),false);assert.ok(all('#importWarnings li').some(li=>/الذكاء الاصطناعي/.test(li.textContent)));
    // everything else the photo said is offered, and what the guide already holds is not replaced by surprise
    assert.equal($('#importExtras').hidden,false);const extra=key=>$(`#importExtraList input[data-key="${key}"]`);
    assert.deepEqual(all('#importExtraList input').map(i=>i.dataset.key),['title','size_label','unit','measurement_type','category','language','instructions','notes']);
    assert.deepEqual(all('#importExtraList input').map(i=>i.checked),[false,false,true,true,true,true,false,true],'filled fields start unticked');
    assert.match(extra('title').closest('label').textContent,/عنوان من الصورة.*سيستبدل/s);assert.match(extra('unit').closest('label').textContent,/إنش/);assert.match(extra('measurement_type').closest('label').textContent,/قياسات القطعة/);
    extra('size_label').checked=false;
    $('#importApply').click();await settle();
    assert.equal($('#guideTitle').value,'دليل الأحذية','an unticked field is left alone');assert.equal($('#instructions').value.includes('تعليمات من الصورة'),false);assert.equal($('#sizeLabel').value,'الحجم');assert.equal($('#measureType').value,'garment');
    assert.equal($('#importExtras').hidden,true,'the panel closes after applying');
    assert.equal($('#guideUnit').value,'in');assert.equal($('#notes').value,'ملاحظة من الصورة');assert.deepEqual(all('#gridEditor thead th input').map(i=>i.value),['الصدر','EU']);assert.equal($('#gridEditor [data-row="1"][data-cell="0"]').value,'');

    // a second photo with every box ticked replaces the texts too
    $('#importPanel').dispatchEvent(paste);$('#aiRun').click();await settle();
    for(const box of all('#importExtraList input'))box.checked=true;$('#importApply').click();await settle();confirmed=true;
    assert.deepEqual([$('#guideTitle').value,$('#sizeLabel').value,$('#instructions').value],['عنوان من الصورة','المقاس','تعليمات من الصورة']);assert.equal(guideWrap().querySelector('h2').textContent,'عنوان من الصورة');
    input('#guideTitle','دليل الأحذية');input('#sizeLabel','الحجم');

    // ---- take a look from a picture: appearance only, undoable
    {const rowsBefore=$('#gridEditor').innerHTML;const file=new w.File(['x'],'look.png',{type:'image/png'});Object.defineProperty($('#styleFile'),'files',{value:[file],configurable:true});
     $('#styleFile').dispatchEvent(new w.Event('change'));await settle();
     const req=calls.find(c=>c.path.startsWith('size-guide-ai-style'));assert.equal(req.method,'POST');assert.deepEqual(Object.keys(req.body),['image']);assert.match(req.body.image,/^data:image\/jpeg;base64,/);
     assert.equal($('#guideColor').value,'#336699');assert.equal($('[name="guide-table_style"]:checked').value,'lines');assert.equal($('[name="guide-corners"]:checked').value,'sharp');assert.equal($('#gridEditor').innerHTML,rowsBefore,'numbers and names never change');
     assert.equal(hidden('#undoStyle'),false);$('#undoStyle').click();assert.equal($('[name="guide-table_style"]:checked').value,'cards');assert.notEqual($('#guideColor').value,'#336699');}
    // ---- paint mode: click a part of the live table and colour it on its own
    {const root=()=>$('#guidePreview').shadowRoot;assert.equal(hidden('#paintPanel'),true);assert.equal(root().querySelector('.pick'),null);
     change('#paintMode',true);assert.equal(hidden('#paintPanel'),false);assert.equal($('#paintBg').disabled,true,'nothing chosen yet');
     root().querySelectorAll('tbody tr')[0].children[1].click();assert.match($('#paintTarget').textContent,/خلية/);assert.equal(all('#paintScope input').length,3);assert.equal($('#paintBg').disabled,false);
     input('#paintBg','#ffd0d0');assert.equal(root().querySelectorAll('tbody tr')[0].children[1].style.background,'rgb(255, 208, 208)');
     $('[name="paint-scope"][value="col"]').click();input('#paintFg','#202020');change('#paintBold',true);
     assert.equal(root().querySelectorAll('tbody tr')[1].children[1].style.color,'rgb(32, 32, 32)','the whole column');assert.equal(root().querySelectorAll('tbody tr')[1].children[1].style.fontWeight,'700');
     root().querySelector('thead th:nth-child(2)').click();assert.equal(all('#paintScope input').length,2);$('[name="paint-scope"][value="all"]').click();input('#paintBg','#102030');
     assert.equal(root().querySelector('thead th:nth-child(3)').style.background,'rgb(16, 32, 48)');assert.equal($('#paintClearAll').disabled,false);
     $('#paintClearPart').click();assert.equal(root().querySelector('thead th:nth-child(3)').style.background,'');
     // Whole-chart color changes can keep cell overrides, or replace and undo them without losing bold.
     const palette=$('#guidePalettes [data-palette="garnet"]');
     $('#paletteIncludePaint').checked=false;palette.click();
     assert.equal(root().querySelector('tbody tr').children[1].style.background,'rgb(255, 208, 208)');
     $('#undoPalette').click();
     $('#paletteIncludePaint').checked=true;palette.click();
     assert.equal(root().querySelector('tbody tr').children[1].style.background,'');
     assert.equal(root().querySelectorAll('tbody tr')[1].children[1].style.fontWeight,'700');
     $('#undoPalette').click();
     assert.equal(root().querySelector('tbody tr').children[1].style.background,'rgb(255, 208, 208)');
     // the first two parts stay painted for the save below
     }
    // ---- editing right in the live preview: type into cells, add and remove rows and columns
    {const root=()=>$('#guidePreview').shadowRoot,fire=(n,type)=>n.dispatchEvent(new w.Event(type,{bubbles:true}));
     assert.equal(root().querySelector('.ed'),null,'off by default');change('#inlineEdit',true);assert.ok(root().querySelectorAll('.ed').length>5);assert.match($('#inlineEditHint').textContent,/انقر على أي خلية/);
     change('#paintMode',true);assert.equal($('#inlineEdit').checked,false,'painting turns editing off');assert.equal(root().querySelector('.ed'),null);
     change('#inlineEdit',true);assert.equal($('#paintMode').checked,false,'editing turns painting off');assert.ok(root().querySelector('.ed'));
     const span=root().querySelector('.ed[data-part="cell"][data-row="0"][data-col="0"]'),was=span.textContent;fire(span,'focusin');span.textContent='77';fire(span,'focusout');
     assert.equal($('#gridEditor [data-row="0"][data-cell="0"]').value,'77','the table editor follows the preview');assert.match($('#editState').textContent,/غير محفوظة/);assert.equal(root().querySelector('.ed[data-part="cell"][data-row="0"][data-col="0"]'),span,'typing does not redraw the preview');
     span.textContent=was;fire(span,'focusout');assert.equal($('#gridEditor [data-row="0"][data-cell="0"]').value,was);
     const label=root().querySelector('.ed[data-part="head"][data-col="0"]'),oldLabel=label.textContent;fire(label,'focusin');label.textContent='';fire(label,'focusout');assert.equal(label.textContent,oldLabel,'an empty column name is refused');
     label.textContent='عرض الصدر';fire(label,'focusout');assert.equal($('#gridEditor thead th input[data-col="0"]').value,'عرض الصدر');label.textContent=oldLabel;fire(label,'focusout');
     const rowsBefore=all('#gridEditor tbody tr').length,colsBefore=all('#gridEditor thead th input[data-col]').length;
     root().querySelector('.ed-add').click();assert.equal(all('#gridEditor tbody tr').length,rowsBefore+1);assert.equal(root().querySelectorAll('tbody tr').length,rowsBefore+1);
     root().querySelectorAll('tbody tr')[rowsBefore].querySelector('.ed-del').click();await settle();assert.equal(all('#gridEditor tbody tr').length,rowsBefore,'an empty row goes without asking');
     root().querySelector('thead .ed-add-col').click();assert.equal(all('#gridEditor thead th input[data-col]').length,colsBefore+1);assert.equal(root().querySelectorAll('tbody tr:first-child td .ed').length,colsBefore+1);
     [...root().querySelectorAll('thead .ed-del-col')].pop().click();await settle();assert.equal(all('#gridEditor thead th input[data-col]').length,colsBefore);
     change('#inlineEdit',false);assert.equal(root().querySelector('.ed'),null);assert.equal($('#inlineEditHint').textContent,'');}
    // ---- the editor's sections fold like a menu: one open at a time
    {const cards=[...d.querySelectorAll('#editor .ed-card.acc')],open=()=>cards.filter(c=>c.classList.contains('open')).length;
     assert.ok(cards.length>=6,'sections fold');assert.equal(open(),1,'only the first section starts open');
     const target=cards.find(c=>c.querySelector('#themeChoices'));target.querySelector('.acc-btn').click();assert.equal(open(),1);assert.ok(target.classList.contains('open'));assert.equal(target.querySelector('.acc-btn').getAttribute('aria-expanded'),'true');
     target.querySelector('.acc-btn').click();assert.equal(open(),0,'pressing the open title closes it');
     $('#accAll').click();assert.equal(open(),cards.length);$('#accAll').click();assert.equal(open(),1);}
    {
      const appearance = $('#presetCard'), advanced = $('#customCard');
      assert.ok(appearance.contains($('#themeChoices')) && appearance.contains($('#guidePalettes')));
      for (const id of ['guideFont', 'tableColors', 'paintMode', 'myStyles']) {
        assert.ok(advanced.contains($('#'+id)), id+' is grouped under advanced customization');
      }
      assert.equal(advanced.querySelectorAll('details[open]').length, 0);
      const shortcut = [...d.querySelectorAll('.editor-jumps button')].find(b => b.textContent === 'تخصيص متقدم');
      shortcut.click();
      assert.equal(shortcut.getAttribute('aria-expanded'), 'true');
      assert.equal(appearance.querySelector('.acc-btn').getAttribute('aria-expanded'), 'false');
      $('#paintCard').querySelector('summary').click();
      assert.ok($('#paintCard').open);
      const footer = d.querySelector('main > .workspace-footer');
      assert.ok(footer.querySelector('[aria-hidden="true"] [data-fuzz]'));
      assert.equal(footer.querySelector('a').hash, '#workspaceTop');
      assert.equal($('#workspaceTop').tagName, 'MAIN');
    }
    // ---- a second (body) table pasted in, shown with a switch, removable
    {const root=()=>$('#guidePreview').shadowRoot;$('#bodyPaste').value='المقاس\tالطول\tالصدر\nS\t160-165\t82-86\nM\t165-170\t86-90';$('#bodyApply').click();
    assert.equal(root().querySelectorAll('.tvs button').length,2,'the preview shows the product/body switch');assert.match($('#bodyState').textContent,/2 صفًا/);assert.equal($('#bodyRemove').disabled,false);
    $('#bodyTitle').value='جسمك';$('#bodyTitle').dispatchEvent(new w.Event('input',{bubbles:true}));}
    $('#guideFont').value='cairo';$('#guideFont').dispatchEvent(new w.Event('change',{bubbles:true}));assert.ok(w.document.querySelector('link#sg-font-cairo'),'the preview loads the chosen Google font');
    assert.equal(all('#sysChecks input').length,8);const usBox=$('#sysChecks input[data-sys="US"]');usBox.checked=true;usBox.dispatchEvent(new w.Event('change',{bubbles:true}));assert.equal($('#sysAuto').disabled,false);
    // ---- saving sends everything
    $('#saveDraft').click();await settle();
    const put=call('PUT','size-guides/42')[0].body;assert.equal(put.action,'draft');
    assert.equal(put.guide.size_systems.join(),'US','the ticked system is saved');assert.equal(put.guide.font_family,'cairo','the chosen font is saved');assert.equal(put.guide.body_table.title,'جسمك');assert.equal(put.guide.body_table.rows.length,2);assert.deepEqual(put.guide.body_table.columns.map(c=>c.label),['الطول','الصدر']);
    const g=put.guide;assert.deepEqual(g.cell_styles.map(x=>[x.target,x.row,x.col,x.bg,x.fg,x.bold]),[['cell',0,0,'#ffd0d0','',false],['col',-1,0,'','#202020',true]],'painted parts are saved');assert.deepEqual([g.category,g.theme,g.table_style,g.density,g.corners,g.depth3d,g.header_icon],['pets','ranges','cards','compact','round',false,false]);
    assert.deepEqual([g.size_style,g.header_style,g.border_style,g.font_scale,g.sticky_size,g.size_label,g.language,g.calculator],['underline','solid','strong','large',false,'الحجم','ar',true]);
    assert.deepEqual([g.header_bg,g.row_alt,g.border_color,g.size_bg],['','','#ff0000',''],'colours reset to automatic are saved empty; the one picked afterwards is kept');
    assert.deepEqual([g.how_video,g.logo_url],['https://youtu.be/dQw4w9WgXcQ','https://cdn.example.com/logo.png']);assert.deepEqual(g.how_images,['https://cdn.example.com/a.jpg','https://cdn.example.com/b.jpg','1','2']);
    // missing server key: the AI button explains itself
    aiAvailable=false;

    // ---- ready-made looks change only the appearance, and can be undone (none ship by default; the owner adds their own)
    assert.equal(w.SizeGuideCatalog.stylePresets.length,0);assert.equal(all('#presetChoices .preset-card').length,0);assert.equal(hidden('#presetChoices'),true);
    w.SizeGuideCatalog.stylePresets.push({id:'bold',name:'جريء',hint:'ترويسة ممتلئة وحدود واضحة',style:{theme:'slate',table_style:'zebra',density:'comfortable',corners:'sharp',depth3d:false,header_icon:true,size_style:'square',header_style:'solid',border_style:'strong',font_scale:'large',header_bg:'',header_text:'',row_alt:'',border_color:'',text_color:'',paper_color:'',size_bg:'',size_text:'',sticky_size:true}});
    $('#backCatalog').click();await settle();$('[data-edit="42"]').click();await settle();
    const before={rows:JSON.stringify(guideCopy().rows),columns:JSON.stringify(guideCopy().columns),title:$('#guideTitle').value};
    function guideCopy(){return {rows:all('#gridEditor tbody tr').map(tr=>[...tr.querySelectorAll('input')].map(i=>i.value)),columns:all('#gridEditor thead th input').map(i=>i.value)}}
    assert.equal(all('#presetChoices .preset-card').length,1);assert.equal(all('#myPresets .preset-card').length,1);assert.ok($('#presetChoices .preset-mini'));
    assert.equal($('#undoStyle').classList.contains('hidden'),true);
    const oldStyle=[$('[name="guide-table_style"]:checked').value,$('[name="guide-size_style"]:checked').value,$('#guideColor').value];
    all('#presetChoices .preset-pick').find(b=>/جريء/.test(b.textContent)).click();
    assert.deepEqual([$('[name="guide-table_style"]:checked').value,$('[name="guide-size_style"]:checked').value,$('[name="guide-header_style"]:checked').value,$('[name="guide-corners"]:checked').value,$('[name="guide-font_scale"]:checked').value],['zebra','square','solid','sharp','large']);
    assert.equal(guideWrap().dataset.theme,'slate');assert.equal($('[name="guide-theme"]:checked'),null);assert.equal($('#guideColor').value,'#3d4a56');assert.equal(guideWrap().dataset.theme,'slate');assert.equal(guideWrap().dataset.corners,'sharp');
    assert.ok(all('#tableColors .color-field').every(f=>!f.classList.contains('custom')),'a look clears custom colours');
    assert.deepEqual([JSON.stringify(guideCopy().rows),JSON.stringify(guideCopy().columns),$('#guideTitle').value],[before.rows,before.columns,before.title],'the table itself is untouched');
    assert.equal($('#undoStyle').classList.contains('hidden'),false);$('#undoStyle').click();
    assert.deepEqual([$('[name="guide-table_style"]:checked').value,$('[name="guide-size_style"]:checked').value,$('#guideColor').value],oldStyle,'undo restores the previous look');assert.equal($('#undoStyle').classList.contains('hidden'),true);
    // a saved look applies like a built-in one
    all('#myPresets .preset-pick').find(b=>/تصميم قديم/.test(b.textContent)).click();assert.equal(guideWrap().dataset.theme,'velvet');assert.equal($('[name="guide-theme"]:checked'),null);assert.equal($('[name="guide-density"]:checked').value,'compact');$('#undoStyle').click();
    // the store's colour
    $('#brandColor').value='#ffe9a8';$('#applyBrand').click();
    assert.notEqual($('#guideColor').value,'#ffe9a8','a pale brand colour is darkened to stay readable');assert.match($('[name="guide-header_style"]:checked').value,/solid|tint/);
    $('#brandColor').value='#7b2338';$('#applyBrand').click();assert.equal($('#guideColor').value,'#7b2338');assert.equal($('[name="guide-header_style"]:checked').value,'solid');assert.equal(w.localStorage.getItem('sg-brand-123'),'#7b2338');
    $('#undoStyle').click();assert.notEqual($('#guideColor').value,'#7b2338');
    // saving the current look as a named design
    $('#savePreset').click();await settle();assert.equal(call('POST','size-presets').length,0,'a name is required');
    $('[name="guide-theme"][value="numeric"]').click();$('[name="guide-table_style"][value="lines"]').click();input('#presetName','تصميم متجري');$('#savePreset').click();await settle();
    const savedLook=call('POST','size-presets')[0].body;assert.equal(savedLook.kind,'style');assert.equal(savedLook.name,'تصميم متجري');assert.equal(savedLook.style.theme,'numeric');assert.equal(savedLook.style.table_style,'lines');
    assert.equal('title' in savedLook.style||'columns' in savedLook.style||'rows' in savedLook.style||'language' in savedLook.style,false,'only appearance is saved');
    assert.equal(all('#myPresets .preset-card').length,2);assert.equal($('#presetName').value,'');
    confirmed=false;$('#myPresets .preset-x').click();await settle();assert.equal(call('DELETE','size-presets/').length,0);confirmed=true;$('#myPresets .preset-x').click();await settle();assert.equal(call('DELETE','size-presets/').length,1);assert.equal(all('#myPresets .preset-card').length,1);

    // ---- quick phrases under the notes
    const phrases=all('#phraseChips .phrase-pick');assert.ok(phrases.length>=5);assert.ok(phrases.some(b=>b.title==='جملة محفوظة من التاجر'),'saved phrases are listed');
    const first=phrases[0].title;input('#notes','');phrases[0].click();assert.equal($('#notes').value,first);phrases[1].click();assert.equal($('#notes').value,first+'\n'+phrases[1].title);
    const lines=$('#notes').value;phrases[0].click();assert.equal($('#notes').value,lines,'a phrase is never added twice');
    input('#notes','x'.repeat(1995));phrases[0].click();assert.equal($('#notes').value.length,1995,'the 2000-character limit is respected');input('#notes','');
    input('#phraseText','   ');$('#savePhrase').click();await settle();assert.equal(call('POST','size-presets').length,1,'an empty phrase is not saved');
    input('#phraseText','شحن مجاني للمقاسات الكبيرة');$('#savePhrase').click();await settle();assert.equal(call('POST','size-presets')[1].body.kind,'phrase');assert.equal(call('POST','size-presets')[1].body.text,'شحن مجاني للمقاسات الكبيرة');
    assert.ok(all('#phraseChips .phrase-pick').some(b=>b.title==='شحن مجاني للمقاسات الكبيرة'));
    $('#phraseChips .preset-x').click();await settle();assert.equal(call('DELETE','size-presets/').length,2);
    assert.equal(all('#phraseChips .phrase-pick').some(b=>b.title==='جملة محفوظة من التاجر'),false);

    // ---- completing a column and pasting blocks of cells
    $('[name="guide-category"][value="women"]').click();await settle();$('#template').value='women-dresses';confirmed=true;$('#applyTemplate').click();await settle();
    const cell=(r,c)=>$(`#gridEditor [data-row="${r}"][data-cell="${c}"]`);
    $('[data-fill="0"]').click();assert.equal(cell(2,0).value,'','nothing happens without two numbers');
    input('#gridEditor [data-row="0"][data-cell="0"]','86-90');input('#gridEditor [data-row="1"][data-cell="0"]','90-94');$('[data-fill="0"]').click();
    assert.deepEqual([2,3,4].map(r=>cell(r,0).value),['94-98','98-102','102-106']);assert.equal(guideWrap().querySelectorAll('tbody tr').length,5);
    input('#gridEditor [data-row="0"][data-cell="1"]','70');input('#gridEditor [data-row="1"][data-cell="1"]','74');input('#gridEditor [data-row="3"][data-cell="1"]','99');$('[data-fill="1"]').click();
    assert.deepEqual([2,3,4].map(r=>cell(r,1).value),['78','99','86'],'only empty cells are filled');
    const pasteInto=(selector,text)=>{const event=new w.Event('paste',{bubbles:true,cancelable:true});event.clipboardData={getData:()=>text};$(selector).dispatchEvent(event);return event};
    let ev=pasteInto('#gridEditor [data-row="0"][data-cell="2"]','95\t100\n98\t104\n');
    assert.equal(ev.defaultPrevented,true);assert.deepEqual([cell(0,2).value,cell(0,3).value,cell(1,2).value,cell(1,3).value],['95','100','98','104']);
    ev=pasteInto('#gridEditor [data-size="3"]','XL\t1\t2\t3\t4\t5\t6\nXXL\t7\t8\t9\t10\nXXXL\t11');
    assert.equal($('#gridEditor [data-size="3"]').value,'XL');assert.equal($('#gridEditor [data-size="4"]').value,'XXL');assert.equal(all('#gridEditor tbody tr').length,6,'rows are added for the pasted block');assert.equal($('#gridEditor [data-size="5"]').value,'XXXL');
    assert.equal(cell(3,0).value,'1');assert.equal(cell(3,3).value,'4');assert.equal(cell(5,0).value,'11');
    ev=pasteInto('#gridEditor [data-row="0"][data-cell="0"]','777');assert.equal(ev.defaultPrevented,false,'a single value pastes normally');assert.equal(cell(0,0).value,'86-90');
    ev=pasteInto('#gridEditor [data-row="0"][data-cell="0"]','a\nb\nc'.repeat(1)+'\n'+Array.from({length:40},(_,i)=>'r'+i).join('\n'));assert.equal(all('#gridEditor tbody tr').length,30,'the 30-row limit is respected');
    ev=pasteInto('#guideTitle','a\tb\nc\td');assert.equal(ev.defaultPrevented,false,'only the table grid takes blocks');

    // ---- copy a whole table from a picture: numbers, look and layout, each part optional
    {const file=new w.File(['x'],'full.png',{type:'image/png'});Object.defineProperty($('#aiFile'),'files',{value:[file],configurable:true});
     $('#aiClone').click();await settle();
     const req=calls.filter(c=>c.path.startsWith('size-guide-ai-clone')).pop();assert.equal(req.method,'POST');assert.deepEqual(Object.keys(req.body),['image']);
     assert.equal(hidden('#importPreview'),false);const keys=all('#importExtraList input').map(i=>i.dataset.key);assert.ok(keys.includes('look_style')&&keys.includes('look_frame'));assert.ok(all('#importExtraList input').filter(i=>/^look_/.test(i.dataset.key)).every(i=>i.checked));
     assert.match($('#importExtraList').textContent,/نِسَب عرض الأعمدة \+ مكان لصورة المنتج/);
     $('#importApply').click();await settle();
     assert.deepEqual(all('#widthEditor input').map(i=>i.value),['20','40','40']);assert.equal($('[name="guide-side_layout"]:checked').value,'end','left on a right-to-left page is after the table');assert.equal($('#side3d').checked,true);
     assert.equal($('#guideColor').value,'#336699');assert.equal($('[name="guide-table_style"]:checked').value,'lines');
     const root=()=>$('#guidePreview').shadowRoot;assert.equal(root().querySelectorAll('col').length,3);assert.ok(root().querySelector('aside.side'));
     input('#widthEditor input','30');assert.equal(root().querySelector('col').style.width.slice(0,2),'27');
     $('[name="guide-side_layout"][value="none"]').click();assert.equal(root().querySelector('aside.side'),null);$('[name="guide-side_layout"][value="start"]').click();assert.ok(root().querySelector('aside.side'));
     all('#widthEditor button').pop().click();assert.equal(root().querySelector('col'),null);assert.equal(all('#widthEditor input').length,0);assert.equal(all('#widthEditor button').length,1,'offers to set widths again');
     // each part can be left out
     $('#aiClone').click();await settle();for(const i of all('#importExtraList input'))if(/^look_/.test(i.dataset.key))i.checked=false;
     const colorBefore=$('#guideColor').value;$('#importApply').click();await settle();assert.equal($('#guideColor').value,colorBefore);assert.equal(all('#widthEditor input').length,0);}
    // ---- a guide saved before these options existed opens with defaults
    $('#backCatalog').click();await settle();$('[data-edit="43"]').click();await settle();
    assert.equal($('[name="guide-category"]:checked').value,'special');assert.equal(guideWrap().dataset.theme,'classic');assert.equal($('[name="guide-theme"]:checked'),null);assert.equal($('#guideColor').value,'#123456');
    assert.equal($('#depth3d').checked,true);assert.equal($('[name="guide-size_style"]:checked').value,'chip');assert.equal($('#calculator').checked,false,'older guides keep the finder off');assert.equal($('#template').value,'general-basic');
    assert.equal($('#tc-status-header_bg').textContent,'تلقائي');
    w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','');};w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open');this.dispatchEvent(new w.Event('close'));};
    $('#previewModal').click();

    // ---- a product linked to a shared guide is read-only and offers a way out
    $('#backCatalog').click();await settle();$('[data-edit="44"]').click();await settle();
    assert.equal(hidden('#linkedBanner'),false);assert.equal($('#linkedName').textContent,'فساتين');assert.equal($('#editFields').disabled,true);assert.equal(guideWrap().querySelector('h2').textContent,'من المكتبة');
    const savesBefore=calls.filter(c=>c.method==='PUT').length;$('#saveDraft').click();$('#publish').click();await settle();assert.equal(calls.filter(c=>c.method==='PUT').length,savesBefore,'nothing is saved while linked');
    confirmed=false;$('#unlinkThis').click();await settle();assert.equal(call('POST','size-guides/unlink').length,0,'declined unlink does nothing');
    confirmed=true;$('#unlinkThis').click();await settle();assert.deepEqual(call('POST','size-guides/unlink')[0].body.product_ids,['44']);

    // ---- bulk actions in the catalog
    $('#backCatalog').click();await settle();
    assert.equal(hidden('#bulkBar'),true);assert.match($('[data-select="44"]').closest('tr').textContent,/مرتبط · فساتين/);
    $('[data-select="42"]').checked=true;$('[data-select="42"]').dispatchEvent(new w.Event('change'));$('[data-select="44"]').checked=true;$('[data-select="44"]').dispatchEvent(new w.Event('change'));
    assert.equal(hidden('#bulkBar'),false);assert.match($('#bulkCount').textContent,/2/);assert.equal($('#selectAll').indeterminate,true);
    assert.ok(all('#bulkSource option').some(o=>o.value==='43'),'products that have guides can be a source');assert.ok(all('#bulkLibrary option').some(o=>o.value===LIB));
    $('#bulkCopy').click();await settle();assert.equal(call('POST','size-guides/copy').length,0,'a source is required');
    $('#bulkSource').value='43';$('#bulkPublishCopy').checked=true;confirmed=false;$('#bulkCopy').click();await settle();assert.equal(call('POST','size-guides/copy').length,0,'declined copy does nothing');
    confirmed=true;$('#bulkCopy').click();await settle();
    let copy=call('POST','size-guides/copy')[0].body;assert.deepEqual([copy.source_product_id,copy.product_ids,copy.overwrite,copy.publish],['43',['42','44'],false,true]);
    assert.equal(hidden('#bulkBar'),true,'selection clears after an action');
    $('#selectAll').checked=true;$('#selectAll').dispatchEvent(new w.Event('change'));assert.equal(all('#rows [data-select]:checked').length,3);
    $('#bulkLibrary').value=LIB;$('#bulkLink').click();await settle();assert.deepEqual(call('POST','size-library/'+LIB+'/link')[0].body.product_ids,['42','43','44']);
    $('#selectAll').checked=true;$('#selectAll').dispatchEvent(new w.Event('change'));$('#bulkPublish').click();await settle();assert.equal(call('POST','size-guides/bulk')[0].body.action,'publish');
    $('#selectAll').checked=true;$('#selectAll').dispatchEvent(new w.Event('change'));$('#bulkUnpublish').click();await settle();assert.equal(call('POST','size-guides/bulk')[1].body.action,'unpublish');
    $('#selectAll').checked=true;$('#selectAll').dispatchEvent(new w.Event('change'));$('#bulkUnlink').click();await settle();assert.equal(call('POST','size-guides/unlink').length,2);
    $('#selectAll').checked=true;$('#selectAll').dispatchEvent(new w.Event('change'));$('#bulkClear').click();assert.equal(hidden('#bulkBar'),true);assert.equal(all('#rows [data-select]:checked').length,0);

    // ---- library: list, create, link, edit, delete
    $('[data-tab="library"]').click();await settle();
    assert.equal(hidden('#library'),false);assert.equal(all('#libraryList .lib-card').length,1);assert.match($('#libraryList .lib-card').textContent,/فساتين/);assert.ok($('#libraryList svg.emblem'));
    // category rules: choose a shared guide per category, then link the products that have none
    assert.equal(all('#ruleCategory option').length,1);assert.equal($('#ruleLibrary').value.length>0,true);assert.equal($('#ruleApply').disabled,true,'nothing to apply before a rule exists');
    $('#ruleSave').click();await settle();const rulePut=calls.filter(c=>c.method==='PUT'&&c.path.startsWith('size-rules')).pop();assert.deepEqual(Object.keys(rulePut.body).sort(),['category_id','library_id']);assert.equal(rulePut.body.category_id,'100');
    assert.match($('#rulesList').textContent,/فساتين.*←/);assert.equal($('#ruleApply').disabled,false);
    $('#ruleApply').click();await settle();assert.equal(calls.filter(c=>c.method==='POST'&&c.path.startsWith('size-rules/apply')).length,1);assert.equal(hidden('#missingBar'),true,'nothing left without a guide');
    $('#rulesList .rule-row button').click();await settle();assert.equal(calls.filter(c=>c.method==='DELETE'&&c.path.startsWith('size-rules/100')).length,1);assert.equal(all('#rulesList .rule-row').length,0);
    $('#newLibrary').click();await settle();
    assert.equal(hidden('#editor'),false);assert.equal(hidden('.only-library'),false);assert.equal(hidden('.only-product'),true);assert.equal($('#editorKind').textContent,'جدول مشترك');assert.equal($('#linkSearch').disabled,true,'save first, then link');
    assert.equal($('[data-tab="library"]').classList.contains('active'),true);
    const putsBefore=calls.filter(c=>c.method==='POST'&&c.path.startsWith('size-library?')).length;$('#saveDraft').click();await settle();assert.equal(calls.filter(c=>c.method==='POST'&&c.path.startsWith('size-library?')).length,putsBefore,'a name is required');
    input('#libraryName','فساتين نسائية');assert.equal($('#editorTitle').textContent,'فساتين نسائية');$('#saveDraft').click();await settle();
    const created=calls.filter(c=>c.method==='POST'&&c.path.startsWith('size-library?')).pop().body;assert.deepEqual([created.version,created.name,created.action],[0,'فساتين نسائية','draft']);assert.ok(created.guide.columns.length);
    assert.equal($('#linkSearch').disabled,false);assert.equal(hidden('#deleteLibrary'),false);
    $('#linkPicker').open=true;$('#linkPicker').dispatchEvent(new w.Event('toggle'));await settle();
    assert.ok(all('#linkResults input').some(i=>i.value==='43'),'linkable products are listed');
    $('#linkResults input[value="43"]').checked=true;$('#linkSelected').click();await settle();
    assert.deepEqual(call('POST','size-library/'+NEWLIB+'/link')[0].body.product_ids,['43']);assert.ok(all('#libraryProducts .link-row').length>=1);
    input('#guideTitle','عنوان مشترك جديد');confirmed=true;$('#publish').click();await settle();
    const published=calls.filter(c=>c.method==='PUT'&&c.path.startsWith('size-library/'+NEWLIB)).pop().body;assert.deepEqual([published.version,published.action],[1,'publish']);
    $('#libraryProducts .link-row button').click();await settle();assert.equal(call('POST','size-guides/unlink').length,3);
    $('#deleteLibrary').click();await settle();assert.equal(call('DELETE','size-library/').length,1);assert.equal(hidden('#library'),false);
    $('#libraryList .lib-card button').click();await settle();
    assert.equal($('#libraryName').value,'فساتين');assert.equal(guideWrap().querySelector('h2').textContent,'جدول مشترك');assert.equal($('#unpublish').disabled,false);
    $('#backCatalog').click();await settle();assert.equal(hidden('#library'),false,'back from a shared guide returns to the library');

    // ---- statistics
    $('[data-tab="stats"]').click();await settle();
    assert.equal(hidden('#stats'),false);assert.equal(all('#statsCards .card').length,4);assert.match($('#statsCards').textContent,/12|١٢/);assert.equal(all('#statsChart .bar').length,30);
    assert.match($('#insightCards').textContent,/20|٢٠/);assert.match($('#insightCards').textContent,/25%|٢٥%/);assert.equal(all('#insightAlerts .insight-alert').length,1);assert.match($('#insightAlerts').textContent,/المقاس M/);assert.ok($('#insightRows .size-chip.warn'),'the size with many returns is highlighted');assert.equal(hidden('#insightEmpty'),true);
    assert.match($('#statsTop').textContent,/منتج قديم/);assert.equal(hidden('#statsEmpty'),true);
    $('#statsDays').value='7';$('#statsDays').dispatchEvent(new w.Event('change'));await settle();assert.equal(all('#statsChart .bar').length,7);
    assert.equal(errors.length,0,errors.map(e=>e.message).join('\n'));
  }finally{dom.window.close();}
  console.log('PASS: guide editor (categories, themes, size cell, colours, language, finder, media), imports, shared library, linked products, bulk actions and statistics.');
})().catch(error=>{console.error(error);process.exitCode=1;});
